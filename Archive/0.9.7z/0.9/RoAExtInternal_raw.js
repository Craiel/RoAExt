// ==UserScript==
// @name           RoAExt
// @namespace      org.craiel.avaburextended
// @author         Craiel
// @homepage       https://github.com/Craiel/RoAExtRelease
// @description    Extension for Avabur
// @include        https://avabur.com/game.php
// @include        http://avabur.com/game.php
// @include        https://www.avabur.com/game.php
// @include        http://www.avabur.com/game.php
// @version        0.9
// @icon           https://cdn.rawgit.com/Craiel/RoAExtRelease/master/img/logo-16.png
// @icon64         https://cdn.rawgit.com/Craiel/RoAExtRelease/master/img/logo-64.png
// @run-at         document-end
// @grant          GM_getValue
// @grant          GM_setValue
// @grant          GM_deleteValue
// @grant          GM_notification
// @grant          GM_listValues
// @grant          GM_xmlhttpRequest
// @connect        self
// @require        https://cdnjs.cloudflare.com/ajax/libs/buzz/1.1.10/buzz.min.js
// @require        https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.js
// @require        https://cdnjs.cloudflare.com/ajax/libs/canvasjs/1.7.0/jquery.canvasjs.min.js
// @require        https://cdnjs.cloudflare.com/ajax/libs/jquery-te/1.4.0/jquery-te.min.js


// @noframes
// ==/UserScript==

﻿'use strict';
const modules = {
    jQuery: jQuery
};

function RoAModule(name) {
    this.name = name;
}
RoAModule.prototype = {
    name: "NO_NAME",
    loaded: false,
    dependencies: [],
    addDependency: function (name) {
        this.dependencies.push(name);
    },
    checkDependencies: function () {
        for(var i = 0; i < this.dependencies.length; i++) {
            var module = modules[this.dependencies[i]];
            if(module && module.loaded) {
                continue;
            }
            console.error("Dependency for module " + this.name + " was not satisfied: " + this.dependencies[i]);
            return false;
        }
        return true;
    },
    load: function () {
        this.loaded = true;
        var loadString = " - Loaded Module " + this.name;
        if(modules.logger) {
            modules.logger.log(loadString);
        } else {
            console.log(loadString);
        }
    }
};
Object.spawn = function (parent, props) {
    var defs = {}, key;
    for (key in props) {
        if (props.hasOwnProperty(key)) {
            defs[key] = {value: props[key], enumerable: true, configurable: true, writable: true};
        }
    }
    return Object.create(parent, defs);
};

(function ($) {
    'use strict';
    const RequestAutoSendCheckFrequency = 100;
    const RequestSendThreshold = 500; // the time where we will warn about frequent requests to the same page
    var nextId = 1;
    var rcvForwards = [];
    var forwards = [];
    var targetedForwards = {};
    var targetedRcvForwards = {};
    var requestHistory = {};
    var autoRequests = {};
    function onAjaxSuccess(e, res, req, jsonData) {
        modules.ajaxHooks.idle = false;
        var requestData = {
            id: nextId++,
            date: new Date(),
            url: req.url,
            json: jsonData || {}
        };
        if(requestHistory[requestData.url]) {
            var timeSinceLastRequest = requestData.date - requestHistory[requestData.url];
            if(timeSinceLastRequest < RequestSendThreshold) {
                console.warn("Same request was done recently (" + requestData.url + ")");
            }
        }
        requestHistory[requestData.url] = requestData.date;
        if (autoRequests[requestData.url]) {
            autoRequests[requestData.url].locked = false;
        }
        for(var entry in targetedForwards) {
            if(requestData.url === entry) {
                for (var i = 0; i < targetedForwards[entry].length; i++) {
                    targetedForwards[entry][i](requestData);
                }
                break;
            }
        }
        for (var i = 0; i < forwards.length; i++) {
            forwards[i](requestData);
        }
        modules.ajaxHooks.idle = true;
    }
    
    function onAjaxSendPending(event, jqxhr, options) {
        modules.ajaxHooks.idle = false;
        var requestData = {
            id: nextId++,
            date: new Date(),
            url: options.url,
            options: options || {},
            jqxhr: jqxhr
        };
        for(var entry in targetedRcvForwards) {
            if(requestData.url === entry) {
                for (var i = 0; i < targetedRcvForwards[entry].length; i++) {
                    targetedRcvForwards[entry][i](requestData);
                }
                break;
            }
        }
        for (var i = 0; i < rcvForwards.length; i++) {
            rcvForwards[i](requestData);
        }
        modules.ajaxHooks.idle = true;
    }
    function autoSendAjaxRequests() {
        for (var url in autoRequests) {
            var request = autoRequests[url];
            if(request.locked) {
                continue;
            }
            var timeSinceReceive = new Date() - (requestHistory[url] || 0);
            if(timeSinceReceive >= request.interval) {
                console.log("Auto-sending ajax for " + url);
                request.locked = true;
                if(!request.ajax) {
                    request.ajax = modules.createAjaxRequest(url).post(request.payload);
                }
                request.ajax.send();
            }
        }
    }
    function AjaxHooks() {
        RoAModule.call(this, "Ajax Hooks");
    }
    AjaxHooks.prototype = Object.spawn(RoAModule.prototype, {
        idle: true,
        registerAutoSend: function (url, payload, interval) {
            if(autoRequests[url]) {
                console.error("Url " + url + " is already registered for auto send!");
                return;
            }
            autoRequests[url] = { payload: payload, interval: interval, locked: false };
        },
        register: function(site, callback) {
            if(!targetedForwards[site]) {
                targetedForwards[site] = [];
            }
            targetedForwards[site].push(callback);
        },
        registerRcv: function (site, callback) {
            if(!targetedRcvForwards[site]) {
                targetedRcvForwards[site] = [];
            }
            targetedRcvForwards[site].push(callback);
        },
        registerAll: function (callback) {
            forwards.push(callback);
        },
        registerRcvAll: function (callback) {
            rcvForwards.push(callback);
        },
        load: function () {
            $(document).on("ajaxSend", onAjaxSendPending);
            $(document).on("ajaxSuccess", onAjaxSuccess);
            modules.createInterval("ajaxHooksAutoSend").set(autoSendAjaxRequests, RequestAutoSendCheckFrequency);
            RoAModule.prototype.load.apply(this);
        }
    });
    AjaxHooks.prototype.constructor = AjaxHooks;
    modules.ajaxHooks = new AjaxHooks();
    modules.ajaxRegisterAutoActions = function (callback) {
        modules.ajaxHooks.register("autobattle.php", callback);
        modules.ajaxHooks.register("autoevent.php", callback);
        modules.ajaxHooks.register("autotrade.php", callback);
        modules.ajaxHooks.register("autocraft.php", callback);
    }
})(modules.jQuery);

(function ($) {
    'use strict';
    const Request = function (url) {
        this.url = url;
    };
    Request.prototype = {
        url: null,
        args: null,
        get: function () {
            return this.custom({
                method: "GET"
            });
        },
        post: function (data) {
            return this.custom({
                method: "POST",
                data: data || {}
            });
        },
        custom: function (customArgs) {
            var methodArgs = $.extend({
                url: this.url
            }, customArgs || {});
            this.args = methodArgs;
            return this;
        },
        send: function () {
            return $.ajax(this.url, this.args);
        }
    };
    modules.createAjaxRequest = function (url) {
        return new Request(url);
    };
})(modules.jQuery);

(function ($) {
    'use strict';
    function updateIngredientIdsFromQuery(result) {
        const select = $("<select/>"),
            mats = {};
        select.html(result.filter);
        select.find(">option:not([value=all])").each(function () {
            const $this = $(this);
            mats[$this.text().trim()] = parseInt($this.val());
        });
        window.sessionStorage.setItem("TRADESKILL_MATERIAL_IDS", JSON.stringify(mats));
        modules.cache.TRADESKILL_MATS = mats;
    }
    function Cache() {
        RoAModule.call(this, "Cache");
    }
    Cache.prototype = Object.spawn(RoAModule.prototype, {
        TRADESKILL_MATS: {},
        updateIngredientIds: function() {
            const cached_ids = window.sessionStorage.getItem("TRADESKILL_MATERIAL_IDS");
            if (cached_ids) {
                this.TRADESKILL_MATS = JSON.parse(cached_ids);
            } else {
                $.post("market.php", { type: "ingredient", page: 0, st: "all" }, updateIngredientIdsFromQuery);
            }
        },
        load: function () {
            this.updateIngredientIds();
            RoAModule.prototype.load.apply(this);
        }
    });
    Cache.prototype.constructor = Cache;
    modules.cache = new Cache();
})(modules.jQuery);

(function () {
    'use strict';
    function Constants() {
        RoAModule.call(this, "Constants");
    }
    Constants.prototype = Object.spawn(RoAModule.prototype, {
        BaseResourceUrl: "https://cdn.rawgit.com/Craiel/RoAExtRelease/master/",
        SettingsAutoSaveInterval: 1000,
        SettingsSaveVersion: 1,
        SettingsSaveKey: "settings",
        DungeonWallColor: "#ff0000",
        DungeonRoomSearchedColor: "#ffd700",
        DungeonRoomHasEnemiesColor: "#ff0000",
        DungeonPlayerColor: "#ffffff",
        DungeonMapVersion: 0.1,
        HouseUpdateInterval: 60 * 3 * 1000, // 3 minutes
        ChartUpdateInterval: 60 * 5 * 1000, // 5 minutes
        HarvestRepeaterMinDelay: 60 * 25 * 1000 // 25 minutes
    });
    Constants.prototype.constructor = Constants;
    modules.constants = new Constants();
})();

(function ($) {
    'use strict';
    function CSS() {
        RoAModule.call(this, "CSS");
    }
    CSS.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            const $head = $("head");
            for (var key in modules.urls.css) {
                $head.append("<link type='text/css' rel='stylesheet' href='" + modules.urls.css[key] + "'/>");
            }
            RoAModule.prototype.load.apply(this);
        }
    });
    CSS.prototype.constructor = CSS;
    modules.css = new CSS();
})(modules.jQuery);

(function () {
    'use strict';
    const Interval = function (n) {
        this.name = n;
    };
    Interval.prototype = {
        intervals: {},
        isRunning: function () {
            return typeof(this.intervals[this.name]) !== "undefined"
        },
        clear: function () {
            if (this.isRunning()) {
                clearInterval(this.intervals[this.name]);
                delete this.intervals[this.name];
                return true;
            }
            return false;
        },
        set: function (callback, frequency) {
            this.clear();
            this.intervals[this.name] = setInterval(callback, frequency);
            return this.intervals[this.name];
        }
    };
    modules.createInterval = function (n) {
        return new Interval(n);
    };
})();

(function () {
    const IntervalName = "roaLoader";
    const LoadUpdateTime = 1000;
    var loadOperations = {
        essentials: [],
        optionals: [],
    };
    var loadTimer;
    function loadEnd() {
        RoAModule.prototype.load.apply(this);
        modules.logger.log("Loading finished!");
    }
    function continueLoadOptionals() {
        for (var i = 0; i < loadOperations.optionals.length; i++) {
            if(!loadOperations.optionals[i].loaded) {
                return;
            }
        }
        loadTimer.clear();
        loadEnd();
    }
    function beginLoadOptionals() {
        loadTimer.clear();
        modules.logger.log("Loading Optionals");
        for (var i = 0; i < loadOperations.optionals.length; i++) {
            loadOperations.optionals[i].load();
        }
        loadTimer.set(continueLoadOptionals, LoadUpdateTime);
    }
    function continueLoadEssentials() {
        loadTimer.clear();
        for (var i = 0; i < loadOperations.essentials.length; i++) {
            if(!loadOperations.essentials[i].loaded) {
                return;
            }
        }
        loadTimer.set(beginLoadOptionals, LoadUpdateTime);
    }
    function beginLoadEssentials() {
        loadTimer.clear();
        modules.logger.log("Loading Essentials");
        for (var i = 0; i < loadOperations.essentials.length; i++) {
            loadOperations.essentials[i].load();
        }
        loadTimer.set(continueLoadEssentials, LoadUpdateTime);
    }
    function Loader() {
        RoAModule.call(this, "Loader");
    }
    Loader.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            modules.logger.log("Initializing Module Loader");
            if(this.loadCallback) {
                this.loadCallback();
            }
            loadTimer = modules.createInterval(IntervalName);
            loadTimer.set(beginLoadEssentials, LoadUpdateTime);
            RoAModule.prototype.load.apply(this);
        },
        register: function (module, isEssential) {
            isEssential = isEssential || false;
            if(isEssential) {
                loadOperations.essentials.push(module);
            } else {
                loadOperations.optionals.push(module);
            }
        }
    });
    Loader.prototype.constructor = Loader;
    modules.loader = new Loader();
})();

(function () {
    'use strict';
    function Logger() {
        RoAModule.call(this, "Logger");
    }
    Logger.prototype = Object.spawn(RoAModule.prototype, {
        formatMessage: function (msg, type) {
            var type = type || "info";
            var d = new Date();
            var time = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
            return "[" + time + "] " + GM_info.script.name + "." + type + ": " + msg;
        },
        log: function (msg) {
            console.log(this.formatMessage(msg));
        },
        warn: function (msg) {
            console.log(this.formatMessage(msg));
        },
        error: function (msg) {
            console.log(this.formatMessage(msg));
        }
    });
    Logger.prototype.constructor = Logger;
    modules.logger = new Logger();
})();

(function () {
    'use strict';
    var enabled = false;
    var module = {};
    function send(msg) {
        if(!enabled) {
            return;
        }
        new Notification('Relics of Avabur', {
            body: msg,
        });
    }
    function Notifications() {
        RoAModule.call(this, "Notifications");
    }
    Notifications.prototype = Object.spawn(RoAModule.prototype, {
        error: function (msg) {
            modules.logger.error(msg);
            send('ERROR: ' + msg);
        },
        notice: function (msg) {
            modules.logger.log(msg);
            send('NOTE: ' + msg);
        },
        warn: function (msg) {
            modules.logger.warn(msg);
            send('WARNING: ' + msg);
        },
        incompatibility: function (what) {
            this.error("Your browser does not support " + what +
                ". Please <a href='https://www.google.co.uk/chrome/browser/desktop/' target='_blank'>" +
                "Download the latest version of Google Chrome</a>");
        },
        load: function () {
            if (Notification.permission !== "granted") {
                Notification.requestPermission(function () {
                    enabled = true;
                });
            } else {
                enabled = true;
            }
            RoAModule.prototype.load.apply(this);
        }
    });
    Notifications.prototype.constructor = Notifications;
    modules.notification = new Notifications();
})();

(function () {
    'use strict';
    function onCaptchaSolved(requestData) {
        modules.session.lockAutomation = false;
    }
    function Session() {
        RoAModule.call(this, "Session");
    }
    Session.prototype = Object.spawn(RoAModule.prototype, {
        lockAutomation: false,
        dungeonNeedsUpdate: true,
        captchaEncountered: function () {
            if(modules.settings.settings.notification.captcha.show && modules.settings.settings.notification.enable) {
                modules.notification.warn("Captcha required!");
            }
        },
        load: function () {
            modules.ajaxHooks.register("captcha_submit.php", onCaptchaSolved);
            RoAModule.prototype.load.apply(this);
        }
    });
    Session.prototype.constructor = Session;
    modules.session = new Session();
})();

(function() {
    'use strict';
    /**
     * Creates a GitHub CDN URL
     * @param {String} path Path to the file without leading slashes
     * @param {String} [author] The author. Defaults to Alorel
     * @param {String} [repo] The repository. Defaults to avabur-improved
     * @returns {String} The URL
     */
    const makeUrl = function (path) {
        return modules.constants.BaseResourceUrl + path;
    };
    function URLS() {
        RoAModule.call(this, "URLS");
    }
    URLS.prototype = Object.spawn(RoAModule.prototype, {
        sfx: {
            circ_saw: makeUrl("sfx/circ_saw.wav"),
            message_ding: makeUrl("sfx/message_ding.wav")
        },
        css: {
            jquery_te: "https://cdnjs.cloudflare.com/ajax/libs/jquery-te/1.4.0/jquery-te.min.css",
            script: "https://rawgit.com/Craiel/RoAExtRelease/master/RoAExt.css"
        },
        gif: {
            ajax_loader: makeUrl("img/ajax-loader.gif")
        },
        svg: {
            sword_clash: makeUrl("svg/sword-clash.svg"),
            log: makeUrl("svg/log.svg"),
            metal_bar: makeUrl("svg/metal-bar.svg"),
            stone_block: makeUrl("svg/stone-block.svg"),
            fishing: makeUrl("svg/fishing.svg")
        }
    });
    URLS.prototype.constructor = URLS;
    modules.urls = new URLS;
})();

(function($) {
    'use strict';
    var module = {};
    module.parseTimeStringLong = function (str) {
        var time = 0;
        const match = str.match(/([0-9]+\s+(hours?|minutes?|seconds?))/g);
        for (var i = 0; i < match.length; i++) {
            const currentMatch = match[i].toLowerCase();
            const number = currentMatch.match(/[0-9]+/);
            var multiplier;
            if (currentMatch.indexOf("hour") !== -1) {
                multiplier = 3600000;
            } else if (currentMatch.indexOf("minute") !== -1) {
                multiplier = 60000;
            } else {
                multiplier = 1000;
            }
            time += parseInt(number) * multiplier;
        }
        return time;
    };
    module.svg = function ($this, url) {
        $this.html('<img src="' + modules.urls.gif.ajax_loader + '" alt="Loading"/>');
        $.get(url).done(function (r) {
            $this.html($(r).find("svg"));
        });
        return $this;
    };
    module.pad = function(value, width, padWith) {
        padWith = padWith || '0';
        value = value + '';
        return value.length >= width ? value : new Array(width - value.length + 1).join(padWith) + value;
    };
    module.getElementIntValue = function (elementId) {
        return parseInt($('#' + elementId).text().replace(/\,/g, ''));
    };
    modules.utils = module;
})(modules.jQuery);

(function ($) {
    'use strict';
    modules.chartTimeScale = {
        Minute: {title: "Minutes"},
        Hour: {title: "Hours"},
        Day: {title: "Days"},
        Month: {title: "Months"}
    };
    const Chart = function (toggleDiv, targetDiv, title, type) {
        this.id = targetDiv;
        this.data = modules.createChartData();
        this.initialize(toggleDiv, targetDiv, title, type);
    };
    Chart.prototype = {
        id: "ERR",
        visible: false,
        onBecameVisible: null,
        toggle: null,
        target: null,
        isGameStatChart: false,
        isElementChart: false,
        gameStatDataPoint: null,
        elementDataPoint: null,
        scale: modules.chartTimeScale.Minute,
        data: null,
        initialize: function (toggleDiv, targetDiv, title, type) {
            var type = type || "line";
            this.toggleDiv = $('#' + toggleDiv);
            this.toggleDiv.click({self: this}, function(evt) { evt.data.self.show(); });
            this.targetDiv = $('#' + targetDiv);
            this.control = new CanvasJS.Chart(targetDiv, {
                title:{
                    text: title
                },
                data: [
                    {
                        type: type,
                        color: "blue",
                        dataPoints: []
                    }
                ],
                axisX:{
                    title : "Time",
                },
                axisY:{
                    title : "Value",
                },
            });
            this.updateControlState();
        },
        load: function (data) {
            this.data.load(data);
            this.updateChartData();
            this.render();
        },
        save: function () {
            return this.data.save();
        },
        reset: function () {
            this.data.reset();
            this.updateChartData();
            this.render();
        },
        show: function () {
            if(this.visible === true) {
                return;
            }
            this.visible = true;
            this.updateControlState();
            this.render();
            if(this.onBecameVisible) {
                this.onBecameVisible(this.id);
            }
        },
        hide: function () {
            if(this.visible === false) {
                return;
            }
            this.visible = false;
            this.updateControlState();
            this.render();
        },
        updateChartData: function () {
            var newData = this.data.getData(this.scale);
            this.control.options.data[0].dataPoints = [];
            for(var i = 0; i < newData.length; i++) {
                this.control.options.data[0].dataPoints.push({label: modules.utils.pad(newData[i][0], 2), x: i, y: newData[i][1]});
            }
            this.updateChartAxis();
        },
        updateChartAxis: function () {
            var controlData = this.control.options.data[0].dataPoints;
            var min = null;
            var max = null;
            for (var i = 0; i < controlData.length; i++) {
                if(min === null || min > controlData[i].y) {
                    min = controlData[i].y;
                }
                if(max === null || max < controlData[i].y) {
                    max = controlData[i].y;
                }
            }
            this.control.options.axisY.minimum = min;
            this.control.options.axisY.maximum = max;
            this.control.options.axisX.title = this.scale.title;
        },
        updateData: function (dataPoint) {
            if(dataPoint == null || isNaN(dataPoint)) {
                return
            }
            this.data.addDataPoint(dataPoint);
            this.updateChartData();
        },
        updateDataFromGameStats: function (stats) {
            if(!this.isGameStatChart) {
                return;
            }
            this.updateData(stats[this.gameStatDataPoint]);
        },
        updateDataFromElement: function() {
            var value = modules.utils.getElementIntValue(this.elementDataPoint);
            this.updateData(value);
        },
        asGameStatChart: function (dataPoint) {
            this.isGameStatChart = true;
            this.gameStatDataPoint = dataPoint;
            return this;
        },
        asElementChart: function (dataPoint) {
            this.isElementChart = true;
            this.elementDataPoint = dataPoint;
            return this;
        },
        asAdditive: function () {
            this.data.additive = true;
            return this;
        },
        updateControlState: function() {
            if(this.visible === false) {
                this.targetDiv.hide();
                return;
            }
            this.targetDiv.show();
        },
        render: function () {
            this.control.render();
        },
        setTimeScale: function (newScale) {
            this.scale = newScale;
            this.updateChartData();
            this.render();
        }
    };
    modules.createChart = function (toggleDiv, targetDiv, title, type) {
        return new Chart(toggleDiv, targetDiv, title, type);
    };
})(modules.jQuery);

(function () {
    'use strict';
    const CURRENT_STORAGE_VERSION = 1;
    const ChartData = function () {
        this.reset();
    };
    ChartData.prototype = {
        storage: null,
        additive: false,
        addDataPoint: function(dataPoint) {
            var dataPointTime = new Date();
            var dataPointMinute = dataPointTime.getMinutes();
            var dataPointHour = dataPointTime.getHours();
            var dataPointDay = dataPointTime.getDate();
            var dataPointMonth = dataPointTime.getMonth() + 1;
            this.addData("mi", dataPointMinute, dataPoint, 60); // 1 hour
            this.addData("h", dataPointHour, dataPoint, 24 * 30); // 30 days
            this.addData("d", dataPointDay, dataPoint, 356); // 1 year
            this.addData("mo", dataPointMonth, dataPoint, 12 * 5); // 5 years
        },
        addData: function (key, id, value, limit) {
            if(!this.storage[key]) {
                this.storage[key] = [];
            }
            if(this.storage[key].length > 0) {
                var existingEntry = this.storage[key][this.storage[key].length - 1];
                if (existingEntry[0] === id) {
                    if (this.additive) {
                        existingEntry[1] += value;
                    }
                    return;
                }
            }
            this.storage[key].push([id, value]);
            while (this.storage[key].length > limit) {
                this.storage[key].shift();
            }
        },
        load: function (data) {
            this.storage = JSON.parse(data);
            if(this.storage.version !== CURRENT_STORAGE_VERSION) {
                console.warn("Chart data is too old and was reset!");
                this.reset();
            }
        },
        save: function () {
            return JSON.stringify(this.storage);
        },
        reset: function () {
            this.storage = {version:CURRENT_STORAGE_VERSION, mi: [], h:[], d:[], mo:[]};
        },
        getData: function (scale) {
            if(scale === modules.chartTimeScale.Minute) {
                return this.storage.mi;
            } else if (scale === modules.chartTimeScale.Hour) {
                return this.storage.h;
            } else if (scale === modules.chartTimeScale.Day) {
                return this.storage.d;
            } else if (scale === modules.chartTimeScale.Month) {
                return this.storage.mo;
            }
        }
    };
    modules.createChartData = function () {
        return new ChartData();
    };
})();

(function ($) {
    'use strict';
    var chartWindow;
    var template;
    var visibleChart = null;
    var activeCharts = {};
    function onAutoBattle(requestData) {
        if(requestData.json.b) {
            if(requestData.json.b.xp && requestData.json.b.xp > 0) {
                activeCharts['chartPlayerBattleXP'].updateData(requestData.json.b.xp);
            }
            if(requestData.json.b.g && requestData.json.b.g > 0) {
                activeCharts['chartPlayerGoldLooted'].updateData(requestData.json.b.g);
            }
        }
    }
    function onAutoTrade(requestData) {
        if(requestData.json.a && requestData.json.a.xp && requestData.json.a.xp > 0) {
            activeCharts['chartPlayerHarvestXP'].updateData(requestData.json.a.xp);
        }
    }
    function onAutoCraft(requestData) {
        if(requestData.json.a && requestData.json.a.xp && requestData.json.a.xp > 0) {
            activeCharts['chartPlayerCraftingXP'].updateData(requestData.json.a.xp);
        }
    }
    function onStatsReceived(requestData) {
        for (var id in activeCharts) {
            if (activeCharts[id].isGameStatChart) {
                activeCharts[id].updateDataFromGameStats(requestData.json);
            } else if (activeCharts[id].isElementChart) {
                activeCharts[id].updateDataFromElement();
            }
        }
        redrawChart();
        saveChartData();
    }
    function loadChartData() {
        if(!localStorage.chartData) {
            return;
        }
        var data = JSON.parse(localStorage.chartData);
        for (var id in data) {
            if(activeCharts[id]) {
                activeCharts[id].load(data[id]);
            }
        }
    }
    function saveChartData() {
        var data = {};
        for (var id in activeCharts) {
            data[id] = activeCharts[id].save();
        }
        localStorage.chartData = JSON.stringify(data);
        $('#gameChartStorageSize').text(localStorage.chartData.length * 2);
    }
    function resetCharts() {
        if(window.confirm("Reset chart data?")) {
            for (var id in activeCharts) {
                activeCharts[id].reset();
            }
        }
    }
    function redrawChart() {
        if (visibleChart) {
            visibleChart.render();
        }
    }
    function debugChart() {
        if (visibleChart) {
            console.log(visibleChart);
        }
    }
    function setChartTimeScale(scale) {
        for (var id in activeCharts) {
            activeCharts[id].setTimeScale(scale);
        }
    }
    function toggleGameChartPlayerTabs() {
        hideTabCategories();
        $('#gameChartPlayerTabs').show();
    }
    function toggleGameChartStatsTabs() {
        hideTabCategories();
        $('#gameChartStatsTabs').show();
    }
    function toggleGameChartMarketTabs() {
        hideTabCategories();
        $('#gameChartMarketTabs').show();
    }
    function hideTabCategories() {
        $('#gameChartPlayerTabs').hide();
        $('#gameChartStatsTabs').hide();
        $('#gameChartMarketTabs').hide();
    }
    function setupChart(toggleDiv, targetDiv, title, type) {
        var chart = modules.createChart(toggleDiv, targetDiv, title, type);
        activeCharts[chart.id] = chart;
        chart.onBecameVisible = function (id) {
            if(visibleChart == activeCharts[id]) {
                return;
            }
            if (visibleChart) {
                visibleChart.hide();
            }
            visibleChart = activeCharts[id];
        };
        return chart;
    }
    function toggleWindow() {
        modules.chartWindow.toggle();
    }
    function ChartWindow() {
        RoAModule.call(this, "Chart Window");
    }
    ChartWindow.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function() {
            chartWindow = $(template);
            chartWindow.appendTo("body");
            chartWindow.draggable({handle:"#gameChartTitle"});
            chartWindow.hide();
            $('#gameChartWindowClose').click(function () {
                chartWindow.hide();
            });
            $('#gameChartReset').click(resetCharts);
            $('#gameChartRedraw').click(redrawChart);
            $('#gameChartDebugData').click(debugChart);
            $('#gameChartTimeMinute').click(function () { setChartTimeScale(modules.chartTimeScale.Minute); });
            $('#gameChartTimeHour').click(function () { setChartTimeScale(modules.chartTimeScale.Hour); });
            $('#gameChartTimeDay').click(function () { setChartTimeScale(modules.chartTimeScale.Day); });
            $('#gameChartTimeMonth').click(function () { setChartTimeScale(modules.chartTimeScale.Month); });
            $('#toggleGameChartPlayer').click(toggleGameChartPlayerTabs);
            $('#toggleGameChartStats').click(toggleGameChartStatsTabs);
            $('#toggleGameChartMarket').click(toggleGameChartMarketTabs);
            toggleGameChartPlayerTabs();
            setupChart("toggleChartPlayerBattleXP", "chartPlayerBattleXP", "Battle XP", "column").asAdditive();
            setupChart("toggleChartPlayerHarvestXP", "chartPlayerHarvestXP", "Harvest XP", "column").asAdditive();
            setupChart("toggleChartPlayerCraftingXP", "chartPlayerCraftingXP", "Crafting XP", "column").asAdditive();
            setupChart("toggleChartPlayerGold", "chartPlayerGold", "Gold").asElementChart("gold");
            setupChart("toggleChartPlayerGoldLooted", "chartPlayerGoldLooted", "Gold Looted", "column").asAdditive();
            setupChart("toggleChartPlayerPlatinum", "chartPlayerPlatinum", "Platinum").asElementChart("platinum");
            setupChart("toggleChartPlayerCrystal", "chartPlayerCrystal", "Crystals").asElementChart("premium");
            setupChart("toggleChartPlayerMaterial", "chartPlayerMaterial", "Material").asElementChart("crafting_materials");
            setupChart("toggleChartPlayerFragment", "chartPlayerFragment", "Fragments").asElementChart("gem_fragments");
            setupChart("toggleChartPlayerFood", "chartPlayerFood", "Food").asElementChart("food");
            setupChart("toggleChartPlayerWood", "chartPlayerWood", "Wood").asElementChart("wood");
            setupChart("toggleChartPlayerIron", "chartPlayerIron", "Iron").asElementChart("iron");
            setupChart("toggleChartPlayerStone", "chartPlayerStone", "Stone").asElementChart("stone");
            setupChart("toggleChartMonsterSlain", "chartMonsterSlain", "Monsters Slain").asGameStatChart("AllTimeKills");
            setupChart("toggleChartGoldLooted", "chartGoldLooted", "Gold Looted").asGameStatChart("AllTimeGoldLooted");
            setupChart("toggleChartGoldInGame", "chartGoldInGame", "Gold in Game").asGameStatChart("AllTimeCurrentGold");
            setupChart("toggleChartResourcesInGame", "chartResourcesInGame", "Resources in Game").asGameStatChart("AllTimeCurrentRes");
            setupChart("toggleChartPlatinumInGame", "chartPlatinumInGame", "Platinum in Game").asGameStatChart("AllTimeCurrentPlat");
            setupChart("toggleChartMaterialInGame", "chartMaterialInGame", "Crafting Materials in Game").asGameStatChart("AllTimeCurrentMats");
            setupChart("toggleChartFragmentInGame", "chartFragmentInGame", "Gem Fragments in Game").asGameStatChart("AllTimeCurrentFrags");
            setupChart("toggleChartHarvests", "chartHarvests", "Harvests").asGameStatChart("AllTimeHarvests");
            setupChart("toggleChartResourcesHarvested", "chartResourcesHarvested", "Resources Harvested").asGameStatChart("AllTimeResources");
            setupChart("toggleChartItemsFound", "chartItemsFound", "Items found").asGameStatChart("AllTimeItemsFound");
            setupChart("toggleChartMarketCrystals", "chartMarketCrystals", "Crystals");
            setupChart("toggleChartMarketPlatinum", "chartMarketPlatinum", "Platinum");
            setupChart("toggleChartMarketFood", "chartMarketFood", "Food");
            setupChart("toggleChartMarketWood", "chartMarketWood", "Wood");
            setupChart("toggleChartMarketIron", "chartMarketIron", "Iron");
            setupChart("toggleChartMarketStone", "chartMarketStone", "Stone");
            setupChart("toggleChartMarketMaterial", "chartMarketMaterial", "Material");
            setupChart("toggleChartMarketFragment", "chartMarketFragment", "Fragments");
            loadChartData();
            modules.ajaxHooks.register("autobattle.php", onAutoBattle);
            modules.ajaxHooks.register("autotrade.php", onAutoTrade);
            modules.ajaxHooks.register("autocraft.php", onAutoCraft);
            modules.ajaxHooks.register("game_stats.php", onStatsReceived);
            modules.ajaxHooks.registerAutoSend("game_stats.php", {}, modules.constants.ChartUpdateInterval);
            modules.uiScriptMenu.addLink("Charts", toggleWindow);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.chartWindow;
            this.continueLoad();
        },
        toggle: function () {
            chartWindow.toggle();
        }
    });
    ChartWindow.prototype.constructor = ChartWindow;
    modules.chartWindow = new ChartWindow();
})(modules.jQuery);

(function($) {
    'use strict';
    var peopleMod = {};
    if(localStorage.peopleMod)
        peopleMod = JSON.parse(localStorage.peopleMod);
    function addChatColorPicker() {
        $('head').append('<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.css"><style>.sp-replacer{border: 1px solid #01b0aa; background: #01736D;}</style>');
        $('#profileOptionProfile').after(' . <input type="text" id="profileOptionColor" />');
        $("#profileOptionColor").spectrum({
            showInput: true,
            showInitial: true,
            allowEmpty: true,
            clickoutFiresChange: false,
            change: function(color) {
                if(color == null && ($('#profileOptionUsername').text() in peopleMod)) {
                    peopleMod[$('#profileOptionUsername').text()] = 'white';
                    modChatColors();
                    delete peopleMod[$('#profileOptionUsername').text()];
                    savePeopleMod();
                }
                else {
                    peopleMod[$('#profileOptionUsername').text()] = color.toHexString();
                    modChatColors();
                    savePeopleMod();
                }
            }
        });
        var observer = new MutationObserver(function( mutations ) {
            mutations.forEach(function( mutation ) {
                if( mutation.addedNodes !== null )
                    modChatColors();
                if($('#profileOptionUsername').text() in peopleMod)
                    $("#profileOptionColor").spectrum("set", peopleMod[$('#profileOptionUsername').text()]);
                else {
                    $("#profileOptionColor").spectrum("set", '');
                }
            });
        });
        observer.observe($('#chatMessageList')[0], { childList: true, characterData: true});
        observer.observe($('#profileOptionTooltip')[0], { attributes: true, characterData: true});
    }
    /*function addChatSwap() {
        if(typeof Storage == "undefined")
            alert('Local Storage is not supported on this browser. Chat Swap preference will not be saved next session');
        var arrow = "?";
        if(localStorage.chatmove == "true") {
            var e1 = $('#contentWrapper'), e2 = $('#chatWrapper');
            e1.insertAfter(e2);
            e2.insertAfter('#navWrapper');
            $('#effectInfo').insertBefore('#activityWrapper');
            $('#houseNotificationWrapper').insertBefore('#activityWrapper');
            arrow = "?";
            $('#chatMessageListWrapper').height($('#bottomWrapper').offset().top - $('#chatMessageListWrapper').offset().top -2);
        }
        $('<div style="position: absolute;font-size: 14px;color: #01B0AA;left: 12px;cursor: pointer;padding: 1px;" font-size:="">' + arrow + '</div>').prependTo('#areaWrapper>h5').click(function(){
            localStorage.chatmove = !(localStorage.chatmove == "true");
            var e1 = $('#chatWrapper'), e2 = $('#contentWrapper');
            if(localStorage.chatmove == "true") {
                e1 = $('#contentWrapper'), e2 = $('#chatWrapper');
                $('#effectInfo').insertBefore('#activityWrapper');
                $('#houseNotificationWrapper').insertBefore('#activityWrapper');
                $(this).html('?');
            }
            else {
                $('#effectInfo').appendTo('#rightWrapper');
                $('#houseNotificationWrapper').appendTo('#rightWrapper');
                $(this).html('?');
            }
            e1.insertAfter(e2);
            e2.insertAfter('#navWrapper');
            $('#chatMessageListWrapper').height($('#bottomWrapper').offset().top - $('#chatMessageListWrapper').offset().top -2);
        });
    }*/
    function modChatColors() {
        $('#chatMessageList').find('.profileLink').each(function() {
            if($(this).text() in peopleMod) {
                var text = $(this).next();
                var e = $(this).closest('li').find('span:eq(2)').text();
                if(e.indexOf('Whisper') == -1 && e != '[')
                    text.css('color', peopleMod[$(this).text()]);
            }
        });
    }
    function savePeopleMod() {
        localStorage.peopleMod = JSON.stringify(peopleMod);
    }
    function initialize() {
        $('head').append('<style>.ui-icon, .ui-widget-content .ui-icon {background-image: none;}.closeCustomWindow {position: absolute;right: -12px;top: -12px;font-size: 20px;text-align: center;border-radius: 40px;border: 1px solid black;background: transparent linear-gradient(to bottom, #008681 0%, #003533 100%) repeat scroll 0% 0%;width: 30px;}.closeCustomWindow a {text-decoration: none;}.customWindowWrapper {display: none;z-index: 99;position: absolute !important;top: 120px;left: 15%;}.customWindowContent {padding: 5px;border-bottom-right-radius: 5px;border-bottom-left-radius: 5px}.customWindowContent table {width: 100%;font-size: 12px;}.customWindowContent tbody {border: 1px solid #01B0AA;border-top: none;}.customWindowContent th {text-align: center;color: #FF7;border: 1px solid #01B0AA;}.customWindowContent thead th {background-color: #01736D;font-size: 14px;}.customWindowContent td {text-align: center;}.customWindowContent .bRight {border-right: 1px solid #01B0AA;}</style>');
        /*if(constants.ENABLE_CHAT_BATTLE_SWAP)
            addChatSwap();*/
        if(modules.constants.ENABLE_CHAT_USER_COLOR_PICKER)
            addChatColorPicker();
    }
    function ChatPeopleColor() {
        RoAModule.call(this, "Chat People Colors");
    }
    ChatPeopleColor.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            initialize();
            RoAModule.prototype.load.apply(this);
        }
    });
    ChatPeopleColor.prototype.constructor = ChatPeopleColor;
    modules.chatPeopleColor = new ChatPeopleColor();
})(modules.jQuery);

(function ($) {
    'use strict';
    var options                 = {
        scriptSettings  : {
            purge                       : true,
            channel_remove              : false,
            preview                     : true,
            preview_reset               : false,
            group_wires                 : false,
            at_username                 : true,
            join_channel_link           : true,
            auto_join                   : false,
            profile_tooltip_nickname    : true,
            profile_tooltip_mention     : true,
            profile_tooltip_quickscope  : true
        },
        channelsSettings    : {
            channelMerger       : {
                groups              : [],
                mapping             : {},
                defaultChannels     : {}
            },
            mutedChannels   : []
        },
        version: "3.1"
    };
    var groupsMap               = {};
    var channelLog              = {};
    var mainChannelID           = "2";
    var currentChannel          = "Main";
    var ServerMessagesChannel   = "SML_325725_2338723_CHC";
    var CMDResposeChannel       = "CMDRC_4000_8045237_CHC";
    var WhispersChannel         = "UW_7593725_3480021_CHC";
    var WiresChannel            = "WC_0952340_3245901_CHC";
    var MergedChannelsGroup     = "MCG_105704_4581101_CHC";
    var GlobalChannel           = 1000000000;
    var EventChannel            = 2000000000;
    var chatDirection           = "up";
    var scriptChannels          = [ServerMessagesChannel, CMDResposeChannel, WhispersChannel, WiresChannel];
    var hovering;
    var hoveringOverTab;
    function returnCustomID(channel, resolved, cname, on) {
        var obj =  {
            cID: channel,
            res: resolved,
            name: cname,
            on: typeof on !== "undefined" ? on : name
        };
        return obj;
    }
    function resolveChannelID(channel) {
        var channelID;
        var origChannelName = channel;
        var resolved = true;
        if (channel === "GLOBAL") {
            channel = "Global";
        } else if (channel === "CLAN") {
            channel = "Clan";
        } else if (channel.substr(0,4) === "AREA") {
            channel = "Area";
        } else if (channel === "HELP") {
            channel = "Help";
        } else if (channel === "STAFF") {
            channel = "Staff";
        } else if (channel === "TRADE") {
            channel = "Trade";
        } else if (channel === "Market") {
            return returnCustomID(CMDResposeChannel, true, "");//  info channel changes this later
        } else if (channel === "Whispers Log") {
            return returnCustomID(WhispersChannel, true, channel, origChannelName);
        } else if (channel === "Wires Log") {
            return returnCustomID(WiresChannel, true, channel, origChannelName);
        } else if (channel === "Server Messages") {
            return returnCustomID(ServerMessagesChannel, true, channel, origChannelName);
        } else if (channel.match(/^Level:\s+[0-9]+/)) {
            return returnCustomID(CMDResposeChannel, true, "", origChannelName);//  info channel changes this later
        }
        var map = {
            "Global": "GLOBAL",
            "Clan": "CLAN",
            "Area": "AREA",
            "Help": "HELP",
            "Staff": "STAFF",
            "Trade": "TRADE"
        };
        if (typeof map[origChannelName] !== "undefined") {
            origChannelName = map[origChannelName];
        }
        channelID = 0;
        $("select#chatChannel option").each(function(i,e){
            var n = $(e).attr("name");
            if (n==="channel"+channel) {
                channelID = $(e).attr("value");
            }
        });
        if (options.channelsSettings.channelMerger.groups.indexOf(origChannelName) !== -1) {
            channelID = MergedChannelsGroup + "_MCGID_" + groupsMap[origChannelName];
        }
        if (origChannelName == "GLOBAL"){
            channelID = GlobalChannel;
        }
        if (origChannelName == "Event"){
            channelID = EventChannel;
        }
        if (channelID === 0) {
            resolved = false;
            channelID = "2";// Main
        }
        return returnCustomID(channelID, resolved, channel, origChannelName);
    }
    function resolveChannelColor(channelID, channelName) {
        var color = "";
        try {
            color = $(".chatChannel[data-id=\"" + channelName + "\"]").css("background-color");
        } catch (e) {
            color = "";
        }
        if (color === "" || typeof color === "undefined") {
            $(".chatChannel").each(function(i,e){
                if ($(e).attr("data-id") === channelName) {
                    color = $(e).css("background-color");
                }
            });
        }
        if (channelID === ServerMessagesChannel) {
            color = "#007f23";
        } else if (channelID === CMDResposeChannel) {
            color = "#317D80";
        } else if (channelID === WhispersChannel) {
            color = "#DE3937"; //FF3
        } else if (channelID === WiresChannel) {
            color = "#39DE37"; //FF3
        }
        return color;
    }
    function updateChannelList(channel) {
        var tab = $("#channelTab" + channel.channelID);
        if (tab.length === 0) {
            if (channel.muted) {
                return;
            }
            $("<div>")
                .attr("id", "channelTab" + channel.channelID)
                .attr("data-channel", channel.channelID)
                .addClass("border2 ui-element channelTab")
                .css({
                    color: channel.channelColor
                })
                .appendTo("#channelTabList");
            tab = $("#channelTab" + channel.channelID);
        }
        var channelTabLabel = "#"+channel.channelName;
        tab.text(channelTabLabel).css({color: channel.channelColor});
        if (channel.newMessages && !channel.muted) {
            if ($(".Ch"+channel.channelID+"Badge").length === 0) {
                var badge = $("<span>")
                    .addClass("ChBadge")
                    .addClass("border2")
                    .addClass("Ch"+channel.channelID+"Badge")
                    .text(channel.newMessagesCount)
                    .appendTo("#channelTab"+channel.channelID);
            } else {
                $(".Ch"+channel.channelID+"Badge").text(channel.newMessagesCount);
            }
        }
        if (channel.muted) {
            $("<span>")
                .addClass("ChBadge fa fa-times border2 ui-element")
                .appendTo("#channelTab"+channel.channelID);
        }
    }
    function addSettingsTab() {
        $("<div>")
            .attr("id", "ToASettings")
            .addClass("border2 ui-element ToASettings")
            .prependTo("#channelTabList");
        $("<span>")
            .addClass("fa")
            .addClass("fa-cogs")
            .css({
                color: "#ffd700",
                fontWeight: 500
            })
            .appendTo("#ToASettings");
    }
    function randomInt(min, max) {
        return Math.round( Math.random() * ( max - min ) ) + min;
    }
    function randomColor() {
        var color = "#";
        for (var i = 0; i < 6; i++) {
            color += Math.floor(Math.random()*15).toString(16);
        }
        return color;
    }
    function randomName(min, max) {
        var a = "aeiou".split("");
        var b = "rtzpsdfghklmnbvc".split("");
        var l = randomInt(min, max);
        var name = "";
        for (var i = 0; i < l; i++)
        {
            var charset = i % 2 === 0 ? a : b;
            if ( i === 0 )
            {
                charset = Math.random() < 0.5 ? a : b;
            }
            var letter = charset[randomInt(0, charset.length - 1)];
            name += i === 0 ? letter.toUpperCase() : letter;
        }
        return name;
    }
    function ucfirst(str) {
        var result  = "";
        var first   = str.charAt(0).toUpperCase();
        return first + str.substr(1);
    }
    function loadDependencies() {
        $("<link>")
            .attr({
                rel: "stylesheet",
                href: "//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"
            })
            .appendTo("head");
    }
    function prepareHTML() {
        $("<div>")
            .attr("id", "channelTabListWrapper")
            .insertBefore("#chatMessageListWrapper");
        $("<div>")
            .attr("id", "channelTabList")
            .appendTo("#channelTabListWrapper");
        /**
         * Preview channel
         */
        $("<div>")
            .attr("id", "channelPreviewWrapper")
            .addClass("border2")
            .addClass("ui-element")
            .appendTo("body");
        $("<h5>")
            .css("text-align", "center")
            .appendTo("#channelPreviewWrapper");
        $("<div>")
            .attr("id", "channelPreviewActions")
            .appendTo("#channelPreviewWrapper");
        $("<span>")
            .addClass("border2 ui-element fa fa-check sapphire cpa")
            .attr("id", "CPAReset")
            .attr("title", "Mark as read")
            .appendTo("#channelPreviewActions");
        $("<span>")
            .addClass("border2 ui-element fa fa-eraser emerald cpa")
            .attr("id", "CPAPurge")
            .attr("title", "Clear channel of all messages")
            .appendTo("#channelPreviewActions");
        $("<span>")
            .addClass("border2 ui-element fa fa-unlink ruby cpa")
            .attr("id", "CPARemove")
            .attr("title", "Clear the channel and remove it from tabs\nIf any new messages pop into it, it will come back.")
            .appendTo("#channelPreviewActions");
        $("<div>")
            .attr("id", "channelPreviewContent")
            .appendTo("#channelPreviewWrapper");
        $("<div>")
            .attr("id", "channelPreviewMessages")
            .css({
                padding:"2px",
            })
            .appendTo("#channelPreviewContent");
        $("#channelPreviewContent").mCustomScrollbar({scrollInertia: 250,mouseWheel:{scrollAmount: 40}});
        /**
         * context menu
         */
        $("<div>")
            .attr("id", "channelTabContextMenu")
            .addClass("ui-element navSection")
            .appendTo("body");
        $("<a>")
            .attr("id", "chTabCTMenuMute")
            .text("Mute channel")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-bell-slash titanium")
            .prependTo("#chTabCTMenuMute");
        $("<a>")
            .attr("id", "chTabCTMenuUnMute")
            .text("Un-mute channel")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-bell platinum")
            .prependTo("#chTabCTMenuUnMute");
        $("<a>")
            .attr("id", "chTabCTMenuReset")
            .text("Mark as read")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-check sapphire")
            .prependTo("#chTabCTMenuReset");
        $("<a>")
            .attr("id", "chTabCTMenuLast")
            .text("Show history")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-history materials")
            .prependTo("#chTabCTMenuLast");
        $("<a>")
            .attr("id", "chTabCTMenuPurge")
            .text("Purge messages")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-eraser emerald")
            .prependTo("#chTabCTMenuPurge");
        $("<a>")
            .attr("id", "chTabCTMenuRemove")
            .text("Remove from tabs")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-unlink ruby")
            .prependTo("#chTabCTMenuRemove");
        $("<a>")
            .attr("id", "chTabCTMenuLeave")
            .text("Leave channel")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-arrow-right diamond")
            .prependTo("#chTabCTMenuLeave");
        $("<a>")
            .attr("id", "chTabCTMenuColor")
            .text("Change color")
            .addClass("cctmButton")
            .appendTo("#channelTabContextMenu");
        $("<span>")
            .addClass("ui-element fa fa-crosshairs crystals")
            .prependTo("#chTabCTMenuColor");
        $("#channelTabContextMenu").hide();
        /**
         * settings
         */
        $("<div>")
            .attr("id", "ToASettingsWindow")
            .addClass("border2 ui-element")
            .appendTo("body");
        $("<h5>")
            .css("text-align", "center")
            .text("TabsOfAvabur v"+options.version+" - Settings")
            .appendTo("#ToASettingsWindow");
        $("<div>")
            .attr("id","ToASWMenu")
            .appendTo("#ToASettingsWindow");
        var t = $("<div>")
            .addClass("col-sm-6 text-center");
        var l = t.clone().appendTo("#ToASWMenu");
        var r = t.clone().appendTo("#ToASWMenu");
        $("<button>")
            .attr("type", "button")
            .attr("id", "ToAScriptOptions")
            .addClass("btn btn-primary btn-block")
            .text("Script options")
            .appendTo(l);
        $("<button>")
            .attr("type", "button")
            .attr("id", "ToAChannelMerger")
            .addClass("btn btn-primary btn-block")
            .text("(WIP) Channel Manager")
            .appendTo(r);
        $("<div>").addClass("clearfix").appendTo("#ToASettingsWindow");
        $("<div>")
            .attr("id", "ToASettingsWindowContent")
            .appendTo("#ToASettingsWindow");
        $("<div>")
            .attr("id", "ToASettingsScriptSettings")
            .appendTo("#ToASettingsWindowContent");
        var st  = $("<h6>").addClass("text-center");
        var t2  = $("<label>");
        var t2a = $("<input>").attr({"type":"checkbox"}).addClass("settingsChanger");
        var t2w = t.clone().removeClass("text-center");
        st.clone().text("Script settings").appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Allow channel message purging")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","purge")
                            .prop("checked", options.scriptSettings.purge)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Allow removing channel form tabs")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","channel_remove")
                            .prop("checked", options.scriptSettings.channel_remove)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Preview channel on tab hover")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","preview")
                            .prop("checked", options.scriptSettings.preview)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Allow marking channels as read")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","preview_reset")
                            .prop("checked", options.scriptSettings.preview_reset)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Group wires into their own channel")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","group_wires")
                            .prop("checked", options.scriptSettings.group_wires)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .text(" Make @username clickable")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","at_username")
                            .prop("checked", options.scriptSettings.at_username)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .html(" Make '/join channel' clickable. <span class='fa fa-info-circle ToATooltip' title='After you click on the link, the chat message will be filled with a /join channel text.' data-toggle='tooltip' data-placement='top' data-html='true'></span>")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","join_channel_link")
                            .prop("checked", options.scriptSettings.join_channel_link)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .html(" Autojoin clicked channel. <span class='fa fa-info-circle ToATooltip' title='This is designed to work with the previous option to replace the /join <a>channel</a> message.<br>If this option is enabled, the prefilled message to join a channel will be automatically sent.' data-toggle='tooltip' data-placement='top' data-html='true'></span>")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","auto_join")
                            .prop("checked", options.scriptSettings.auto_join)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .html(" Enable Ni[c]kname shortcut")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","profile_tooltip_nickname")
                            .prop("checked", options.scriptSettings.profile_tooltip_nickname)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .html(" Enable @m[e]ntion shortcut")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","profile_tooltip_mention")
                            .prop("checked", options.scriptSettings.profile_tooltip_mention)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        t2w.clone()
            .append(
                t2.clone()
                    .html(" Enable [Q]uickscope shortcut")
                    .prepend(
                        t2a.clone()
                            .attr("data-setting","profile_tooltip_quickscope")
                            .prop("checked", options.scriptSettings.profile_tooltip_quickscope)
                    )
            )
            .appendTo("#ToASettingsScriptSettings");
        $("<div>").addClass("clearfix").appendTo("#ToASettingsScriptSettings");
        $("<div>")
            .attr("id", "ToASettingsChannelMerger")
            .appendTo("#ToASettingsWindowContent");
        st.clone().text("Muted channels").appendTo("#ToASettingsChannelMerger");
        /**
         * muted channels content added on settings window open
         */
        $("<div>")
            .attr("id", "ToASChMMutedChannelsHolder")
            .addClass("border2 ui-element ToASChannelsHolder")
            .appendTo("#ToASettingsChannelMerger");
        $("<div>").addClass("clearfix").appendTo("#ToASettingsWindow");
        /**
         * channel merger content added on setting window open
         */
        st.clone().text("Channel Merger").appendTo("#ToASettingsChannelMerger");
        $("<div>")
            .attr("id", "ToASChMMergedChannelsHolder")
            .addClass("border2 ui-element ToASChannelsHolder incsort")
            .appendTo("#ToASettingsChannelMerger")
            .before(t2.clone().text("Available Channels:"));
        $("<div>")
            .attr("id", "ToASChMMergedChannelsGroupsHolder")
            .addClass("ui-element ToASChannelsHolder")
            .appendTo("#ToASettingsChannelMerger")
            .before();
        var chgl = t2.clone().text("Channel Groups:").insertBefore("#ToASChMMergedChannelsGroupsHolder");
        $("<button>").addClass("fa fa-plus btn btn-primary emerald pull-right btn-xs").attr("id", "ToASChMAddGroup").insertAfter(chgl);
        $("<div>").addClass("clearfix").appendTo("#ToASettingsChannelMerger");
        $("<div>").addClass("clearfix").appendTo("#ToASettingsWindow");
        $("<div>")
            .attr("id", "ToASettingsSaved")
            .text("Settings have been saved and are applied")
            .addClass("text-center small")
            .appendTo("#ToASettingsWindow");
        $("<span>")
            .attr("id", "ToASettingsWindowClose")
            .addClass("fa fa-times border2 ui-element")
            .appendTo("#ToASettingsWindow");
        /**
         * profile tooltip extras
         */
        var ToAExtraDivider = $("<span>").text(" · ");
        ToAExtraDivider.clone().addClass("ToAPONickname").toggleClass("hidden", !options.scriptSettings.profile_tooltip_nickname).appendTo("#profileOptionTooltip");
        $("<a>").addClass("ToAPONickname").toggleClass("hidden", !options.scriptSettings.profile_tooltip_nickname).text("Ni[c]kname").attr("id", "profileOptionNick").appendTo("#profileOptionTooltip");
        ToAExtraDivider.clone().addClass("ToAPOMention").toggleClass("hidden", !options.scriptSettings.profile_tooltip_mention).appendTo("#profileOptionTooltip");
        $("<a>").addClass("ToAPOMention").toggleClass("hidden", !options.scriptSettings.profile_tooltip_mention).text("@m[e]ntion").attr("id", "profileOptionAt").appendTo("#profileOptionTooltip");
        ToAExtraDivider.clone().addClass("ToAPOQuickscope").toggleClass("hidden", !options.scriptSettings.profile_tooltip_quickscope).appendTo("#profileOptionTooltip");
        $("<a>").addClass("ToAPOQuickscope").toggleClass("hidden", !options.scriptSettings.profile_tooltip_quickscope).text("[Q]uickscope").attr("id", "profileOptionQuickScope").appendTo("#profileOptionTooltip");
        $("#ToASettingsWindow").hide();
        $("#ToASettingsScriptSettings").hide();
        $("#ToASettingsChannelMerger").hide();
        $("#ToASettingsSaved").hide();
        $(".ToATooltip").tooltip();
        $("#ToASettingsWindow").draggable({handle:"h5"});
    }
    var SSN = 0;
    function saveOptions() {
        clearTimeout(SSN);
        var opts = JSON.stringify(options);
        localStorage.setItem("ToAOPTS", opts);
        $("#ToASettingsSaved").show();
        SSN = setTimeout(function(){
            $("#ToASettingsSaved").fadeOut();
        }, 3E3);
    }
    function changeSetting(e) {
        var setting = $(e).attr("data-setting");
        options.scriptSettings[setting] = $(e).prop("checked");
        var match = setting.match("^profile_tooltip_([a-z]+)");
        if (match !== null) {
            var POOption = ucfirst(match[1]);
            $(".ToAPO"+POOption).toggleClass("hidden");
        }
        saveOptions();
    }
    function resetUnreadCount() {
        var channelID                           = hoveringOverTab;
        channelLog[channelID].newMessages       = false;
        channelLog[channelID].newMessagesCount  = 0;
        updateChannelList(channelLog[channelID]);
        $("#channelPreviewWrapper").hide();
        $("#channelTabContextMenu").hide();
    }
    function purgeChannel(andRemove,confirmToo) {
        andRemove       = typeof andRemove==="undefined"?options.scriptSettings.channel_remove:andRemove;
        confirmToo      = typeof confirmToo==="undefined"?false:confirmToo;
        var channelID   = hoveringOverTab;
        var channelName = channelLog[channelID].channelName;
        var confirmText = "Are you sure you want purge the \""+channelName+"\" channel"+(andRemove?" and remove it from tabs":"")+"?\nThis only affects your screen.";
        if (confirmToo || window.confirm(confirmText)){
            $(".chc_"+channelID).remove();
            resetUnreadCount();
            if (andRemove) {
                $("#channelTab"+channelID).remove();
                $("#channelTabMain").click();
                $("#channelPreviewWrapper").hide();
            }
        }
    }
    function loadOptions(){
        var stored = localStorage.getItem("ToAOPTS");
        try {
            var parsed = JSON.parse(stored);
            if (typeof parsed.scriptSettings !== "undefined"){
                if (typeof parsed.scriptSettings.purge !== "undefined") {
                    options.scriptSettings.purge = !!parsed.scriptSettings.purge;
                }
                if (typeof parsed.scriptSettings.channel_remove !== "undefined") {
                    options.scriptSettings.channel_remove = !!parsed.scriptSettings.channel_remove;
                }
                if (typeof parsed.scriptSettings.preview !== "undefined") {
                    options.scriptSettings.preview = !!parsed.scriptSettings.preview;
                }
                if (typeof parsed.scriptSettings.preview_reset !== "undefined") {
                    options.scriptSettings.preview_reset = !!parsed.scriptSettings.preview_reset;
                }
                if (typeof parsed.scriptSettings.group_wires !== "undefined") {
                    options.scriptSettings.group_wires = !!parsed.scriptSettings.group_wires;
                }
                if (typeof parsed.scriptSettings.at_username !== "undefined") {
                    options.scriptSettings.at_username = !!parsed.scriptSettings.at_username;
                }
                if (typeof parsed.scriptSettings.join_channel_link !== "undefined") {
                    options.scriptSettings.join_channel_link = !!parsed.scriptSettings.join_channel_link;
                }
                if (typeof parsed.scriptSettings.auto_join !== "undefined") {
                    options.scriptSettings.auto_join = !!parsed.scriptSettings.auto_join;
                }
                if (typeof parsed.scriptSettings.profile_tooltip_nickname !== "undefined") {
                    options.scriptSettings.profile_tooltip_nickname = !!parsed.scriptSettings.profile_tooltip_nickname;
                }
                if (typeof parsed.scriptSettings.profile_tooltip_mention !== "undefined") {
                    options.scriptSettings.profile_tooltip_mention = !!parsed.scriptSettings.profile_tooltip_mention;
                }
                if (typeof parsed.scriptSettings.profile_tooltip_quickscope !== "undefined") {
                    options.scriptSettings.profile_tooltip_quickscope = !!parsed.scriptSettings.profile_tooltip_quickscope;
                }
            }
            if (typeof parsed.channelsSettings !== "undefined" && typeof parsed.version !== "undefined") {
                if (typeof parsed.channelsSettings.mutedChannels !== "undefined" && Array.isArray(parsed.channelsSettings.mutedChannels)) {
                    options.channelsSettings.mutedChannels = parsed.channelsSettings.mutedChannels;
                }
                if (typeof parsed.channelsSettings.channelMerger !== "undefined") {
                    if (typeof parsed.channelsSettings.channelMerger.groups !== "undefined" && Array.isArray(parsed.channelsSettings.channelMerger.groups)) {
                        for (var ccg in parsed.channelsSettings.channelMerger.groups) {
                            var groupName = parsed.channelsSettings.channelMerger.groups[ccg];
                            if (typeof groupName === "string" && options.channelsSettings.channelMerger.groups.indexOf(groupName) === -1) {
                                options.channelsSettings.channelMerger.groups.push(groupName);
                                groupsMap[groupName] = randomName(3,5) + "_" + randomInt(5,9);
                            }
                        }
                    }
                    if (typeof parsed.channelsSettings.channelMerger.mapping !== "undefined" && typeof parsed.channelsSettings.channelMerger.mapping === "object") {
                        options.channelsSettings.channelMerger.mapping = parsed.channelsSettings.channelMerger.mapping;
                    }
                    if (typeof parsed.channelsSettings.channelMerger.defaultChannels !== "undefined" && typeof parsed.channelsSettings.channelMerger.defaultChannels === "object") {
                        options.channelsSettings.channelMerger.defaultChannels = parsed.channelsSettings.channelMerger.defaultChannels;
                    }
                }
            }
            saveOptions();
        } catch(e) {
            localStorage.removeItem("ToAOPTS");
        }
    }
    function createChannelEntry(newChannel, newChannelID, newChannelColor) {
        channelLog[newChannelID] = {
            channelName: newChannel,
            channelID: newChannelID,
            channelColor: newChannelColor,
            messages: 0,
            newMessages: false,
            newMessagesCount: 0,
            muted: options.channelsSettings.mutedChannels.indexOf(newChannel) !== -1
        };
    }
    function loadAllChannels() {
        $("#chatChannel option").each(function(i,e){
            var channelName     = $(e).text();
            var channelInfo     = resolveChannelID(channelName);
            var channelID       = channelInfo.cID;
            var channelColor    = resolveChannelColor(channelID, channelInfo.name);
            if (typeof channelLog[channelID] === "undefined") {
                createChannelEntry(channelInfo.on, channelID, channelColor);
            }
        });
        if (typeof channelLog[GlobalChannel] === "undefined") {
            createChannelEntry("GLOBAL", GlobalChannel, resolveChannelColor(GlobalChannel, "Global"));
        }
        if (typeof channelLog[EventChannel] === "undefined") {
            createChannelEntry("Event", EventChannel, resolveChannelColor(EventChannel, "Event"));
        }
    }
    function quickScopeUser(){
        if (!options.scriptSettings.profile_tooltip_quickscope) {
            return false;
        }
        $("#chatMessage").text("/whois "+$("#profileOptionTooltip").attr("data-username"));
        $("#chatSendMessage").click();
        $("#profileOptionTooltip").hide();
        setTimeout(function(){$("#channelTab"+CMDResposeChannel).click();},1000);
    }
    function mentionUser() {
        if (!options.scriptSettings.profile_tooltip_mention) {
            return false;
        }
        $("#chatMessage").append(" @"+$("#profileOptionTooltip").attr("data-username")).focus();
        $("#profileOptionTooltip").hide();
    }
    function nicknameUser() {
        if (!options.scriptSettings.profile_tooltip_nickname) {
            return false;
        }
        var username = $("#profileOptionTooltip").attr("data-username");
        $.confirm({
            "title"     : "Nickname for "+username,
            "message"   : "<input type=\"text\" id=\"ToASPONicknameName\" style=\"width:100%;\" placeholder=\"Leave blank to unnickname\">",
            "buttons"   : {
                "Nickname"       : {
                    "class"     : "green",
                    "action"    : function() {
                        var newNick = $("#ToASPONicknameName").val();
                        if (newNick.match(/^\s*$/)) {
                            $("#chatMessage").text("/unnickname "+username);
                        } else {
                            $("#chatMessage").text("/nickname "+username+" "+newNick);
                        }
                        $("#chatSendMessage").click();
                    }
                },
                "Cancel"       : {
                    "class"     : "red",
                    "action"    : function() {
                    }
                }
            }
        });
        setTimeout(function() {
            $("#ToASPONicknameName").val("").focus();
        }, 500);
    }
    function isScriptChannel(channelID) {
        return scriptChannels.indexOf(channelID) !== -1;
    }
    function updateGroupName() {
        var newName     = $(this).val();
        var groupID     = $(this).attr("data-gnid");
        var origName    = options.channelsSettings.channelMerger.groups[groupID];
        var origGID     = groupsMap[origName];
        delete groupsMap[origName];
        groupsMap[newName] = origGID;
        options.channelsSettings.channelMerger.groups[groupID] = newName;
        $(this).parent().attr("data-group", newName);
        for (var x in options.channelsSettings.channelMerger.mapping) {
            if (options.channelsSettings.channelMerger.mapping[x] === origName) {
                options.channelsSettings.channelMerger.mapping[x] = newName;
            }
        }
        var groupChannelID = MergedChannelsGroup + "_MCGID_" + groupsMap[newName];
        if (typeof channelLog[groupChannelID] !== "undefined") {
            channelLog[groupChannelID].channelName = newName;
            updateChannelList(channelLog[groupChannelID]);
        }
        saveOptions();
    }
    function addChannelGroup(i, name) {
        var mcgw    = $("<div>").addClass("border2 incsort input-group");
        var mcgigb  = $("<div>").addClass("input-group-btn");
        var mcgdb   = $("<button>").addClass("ToASChMChGRemove btn btn-primary btn-xs ruby");
        var mcgn    = $("<input>").attr({type:"text",name:"mcg_cn"}).addClass("ToASChMmcgName");
        var mcgID = MergedChannelsGroup + "_MCGID_" + groupsMap[name];
        var wrapper = mcgw.clone().attr({"id": mcgID,"data-group": name}).appendTo("#ToASChMMergedChannelsGroupsHolder");
        var igb = mcgigb.clone().appendTo(wrapper);
        mcgdb.clone().attr("data-gnid", i).html("<i class=\"fa fa-times\"></i>").appendTo(igb);
        mcgn.clone().val(name).attr("data-gnid", i).appendTo(wrapper);
    }
    function handleAjaxSuccess(a,res,req,json) {
        var decide = "";
        var valid = ["up", "down"];
        if (json.hasOwnProperty("cs")) {
            if (valid.indexOf(json.cs) !== -1) {
                decide = json.cs;
            }
        } else if (json.hasOwnProperty("p") && json.p.hasOwnProperty("chatScroll")) {
            if (valid.indexOf(json.p.chatScroll) !== -1) {
                decide = json.p.chatScroll;
            }
        }
        if (decide !== "") {
            chatDirection = decide;
        }
    }
    function versionCompare(v1, v2) {
        var regex   = new RegExp("(\.0+)+");
        v1      = v1.replace(regex, "").split(".");
        v2      = v2.replace(regex, "").split(".");
        var min     = Math.min(v1.length, v2.length);
        var diff = 0;
        for (var i = 0; i < min; i++) {
            diff = parseInt(v1[i], 10) - parseInt(v2[i], 10);
            if (diff !== 0) {
                return diff;
            }
        }
        return v1.length - v2.length;
    }
    function loadMessages(t) {
        if ($("#chatChannel option").length > 2) {
            $("#chatMessageList li:not(.processed)").each(function(i,e){
                var plainText       = $(e).text();
                plainText           = plainText.replace(/^\[X\]\s*/, "");
                plainText           = plainText.replace(/\s+/g, " ");
                var defaultMsg      = plainText.match(/^\[([^\]]+)\]\s*(\[([^\]]+)\])?\s*(.*)/);
                var isClanMoTD      = plainText.replace(/^\[[0-9]+\s+[a-zA-Z]+\,\s*[0-9]+\]\s*/, "").indexOf("Clan Message of the Day:") === 0;
                var isRoAMoTD       = plainText.replace(/^\[[0-9]+\s+[a-zA-Z]+\,\s*[0-9]+\]\s*/, "").indexOf("Message of the Day:") === 0;
                var isServerMsg     = plainText.match(/^\[[^\]]+\]\s*\[\s+.*\s+]$/);
                var isWhisper       = plainText.match(/^\[[^\]]+\]\s*Whisper\s*(to|from)\s*([^:]+)/);
                isWhisper       = isWhisper && $(this).closest("li").find("span:eq(2)").text().indexOf("Whisper") === 0;
                var isWire          = plainText.match(/^\[[^\]]+\]\s*(You|[a-zA-Z]+)\s*wired\s*.*\s*(you|[a-zA-Z]+)\.$/);
                var isChatNotif     = $(e).children(".chat_notification").length > 0 || $(e).hasClass("chat_notification");
                var isChatReconnect = $(e).attr("id") === "websocket_reconnect_line";
                var channel = "";
                if (currentChannel.match(/^[0-9]+$/)){
                    channel = channelLog[currentChannel].channelName;
                } else if (currentChannel.indexOf(MergedChannelsGroup) === 0) {
                    channel = channelLog[currentChannel].channelName;
                } else if (scriptChannels.indexOf(currentChannel) !== -1) {
                    channel = channelLog[currentChannel].channelName;
                } else {
                    channel = currentChannel;
                }
                var channelInfo     = resolveChannelID(channel);
                if (defaultMsg !== null) {
                    channel         = typeof defaultMsg[3] === "undefined" ? "Main" : defaultMsg[3];
                    if (channel !== "Main") {
                        var validate = $(this).closest("li").find("span:eq(2)").text() === "[";
                        var quickscopeinfo = channel.match(/^Level:\s+[0-9]+/);
                        if (!validate && quickscopeinfo === null) {
                            channel = "Main";
                        }
                    }
                    channelInfo     = resolveChannelID(channel);
                }
                if (isClanMoTD) {
                    channel         = "CLAN";
                    channelInfo     = resolveChannelID(channel);
                } else if (isServerMsg){
                    channel         = "Server Messages";
                    channelInfo     = resolveChannelID(channel);
                } else if (isWhisper){
                    channel         = "Whispers Log";
                    channelInfo     = resolveChannelID(channel);
                } else if (isWire && options.scriptSettings.group_wires){
                    channel         = "Wires Log";
                    channelInfo     = resolveChannelID(channel);
                }
                var channelID       = channelInfo.cID;
                channel         = channelInfo.on;
                if (
                    channelID !== CMDResposeChannel &&
                    channelID !== ServerMessagesChannel &&
                    channelID !== WiresChannel &&
                    ( isChatNotif || isChatReconnect)
                ) {
                    channelID       = channelInfo.cID;
                }
                if (channelID === CMDResposeChannel){
                    channel         = "Info Channel";
                }
                var channelColor    = resolveChannelColor(channelID, channelInfo.name);
                if (typeof options.channelsSettings.channelMerger.mapping[channel] !== "undefined") {
                    var groupName   = options.channelsSettings.channelMerger.mapping[channel];
                    var groupID     = options.channelsSettings.channelMerger.groups.indexOf(groupName);
                    channelID       = MergedChannelsGroup + "_MCGID_" + groupsMap[groupName];
                    channel         = groupName;
                    channelColor    = randomColor();
                }
                if (currentChannel != channelID){
                    $(e).addClass("hidden");
                } /*else {
                 $(e).show();
                 }*/
                $(e).addClass("processed");
                $(e).addClass("chc_" + channelID);
                if (typeof channelLog[channelID] === "undefined") {
                    createChannelEntry(channel, channelID, channelColor);
                    /*channelLog[channelID] = {
                     channelName: channel,
                     channelID: channelID,
                     channelColor: channelColor,
                     messages: 0,
                     newMessages: false,
                     newMessagesCount: 0,
                     muted: options.channelsSettings.mutedChannels.indexOf(channel) !== -1
                     };*/
                }
                if (channelID != currentChannel){
                    channelLog[channelID].newMessages = true;
                    channelLog[channelID].newMessagesCount++;
                }
                channelLog[channelID].messages++;
                if (options.channelsSettings.mutedChannels.indexOf(channel) !== -1){
                    $(e).remove();
                }
                if (options.scriptSettings.at_username) {
                    $(e).html($(e).html().replace(/\@([a-zA-Z]+)/g,"@<a class=\"profileLink\">$1</a>"));
                }
                if (options.scriptSettings.join_channel_link) {
                    $(e).html($(e).html().replace(/\/join\s+([^\s]+)\s*([^\s<]+)?/, "/join <a class=\"joinChannel\">$1</a> <span class=\"jcPWD\">$2</span>"));
                }
                updateChannelList(channelLog[channelID]);
            });
        }
        if (typeof t === "undefined") {
            setTimeout(loadMessages, 500);
        }
        if ($("#chatWrapper>div:nth-child(2)").attr("id") === "chatMessageWrapper") {
            $("#channelTabListWrapper").insertBefore("#chatMessageListWrapper");
        }
    }
    function init() {
        loadOptions();
        loadDependencies();
        prepareHTML();
        addSettingsTab();
        loadMessages();
        $("#channelTabListWrapper").mCustomScrollbar({axis:"x",advanced:{autoExpandHorizontalScroll:true}});
        $("#channelTabList").sortable({items:".channelTab",distance: 5});
        $("#channelTabList").disableSelection();
        setTimeout(function(){$("#channelTabList > div:nth-child(2)").click();},2000);
    }
    $(document).on("ajaxSuccess", handleAjaxSuccess);
    $(document).on("change", ".settingsChanger", function(e){
        changeSetting(this);
    });
    $(document).on("click", ".channelTab", function(e){
        $(".channelTab").removeClass("chTabSelected");
        var channelID = $(this).attr("data-channel");
        channelLog[channelID].newMessages = false;
        channelLog[channelID].newMessagesCount = 0;
        updateChannelList(channelLog[channelID]);
        $("#chatMessageList > li:not(.hidden)").addClass("hidden");
        $(".chc_"+channelID).removeClass("hidden");
        $("#channelTab"+channelID).addClass("chTabSelected");
        $("#channelPreviewWrapper").hide();
        currentChannel = channelID;
        if (channelID.match(/^[0-9]+$/) === null) {
            var groupName = channelLog[channelID].channelName;
            if (options.channelsSettings.channelMerger.groups.indexOf(groupName) !== -1) {
                if (typeof options.channelsSettings.channelMerger.defaultChannels[groupName] !== "undefined") {
                    channelID = resolveChannelID(options.channelsSettings.channelMerger.defaultChannels[groupName]).cID;
                }
            }
        }
        var channelOption = $("#chatChannel option[value="+channelID+"]");
        if (channelOption.length > 0){
            $("#chatChannel").val(channelID);
        }
        if (chatDirection === "down") {
            setTimeout(function(){
                $("#chatMessageListWrapper").mCustomScrollbar("scrollTo",  "bottom");
            }, 500);
        }
    });
    $(document).on("click", "#CPAReset, #chTabCTMenuReset", function(){
        resetUnreadCount();
    });
    $(document).on("click", "#CPAReset, #chTabCTMenuLast", function(){
        var channelName = channelLog[hoveringOverTab].channelName;
        var msg = "/last "+channelName;
        if (channelName === "CLAN") {
            msg = "/c /last";
        } else if (options.channelsSettings.channelMerger.groups.indexOf(channelName) !== -1) {
            if (typeof options.channelsSettings.channelMerger.defaultChannels[channelName] !== "undefined") {
                msg = "/last " + options.channelsSettings.channelMerger.defaultChannels[channelName];
            }
        } else if (channelName === "Whispers Log") {
            msg = "/w /last";
        } else if (scriptChannels.indexOf(hoveringOverTab) !== -1) {
            return false;
        }
        $("#chatMessage").text(msg);
        $("#chatSendMessage").click();
    });
    $(document).on("click", "#CPAPurge, #chTabCTMenuPurge", function(){
        var confirmToo = $(this).attr("id") === "chTabCTMenuPurge";
        purgeChannel(false, confirmToo);
    });
    $(document).on("click", "#CPARemove, #chTabCTMenuRemove", function(){
        var confirmToo = $(this).attr("id") === "chTabCTMenuRemove";
        purgeChannel(true, confirmToo);
    });
    $(document).on("click", "#chTabCTMenuLeave", function(){
        var channelName = channelLog[hoveringOverTab].channelName;
        purgeChannel(true, true);
        $("#chatMessage").text("/leave " + channelName);
        $("#chatSendMessage").click();
    });
    $(document).on("click", "#chTabCTMenuColor", function(){
        if (hoveringOverTab.indexOf(MergedChannelsGroup) !== -1) {
            var color = randomColor();
            channelLog[hoveringOverTab].channelColor = color;
            updateChannelList(channelLog[hoveringOverTab]);
        } else {
            $.alert("Tab color change failed! Please try again!", "Group tab color change");
        }
    });
    $(document).on("click", "#chTabCTMenuMute", function(){
        if (typeof hoveringOverTab === "undefined"){
            return;
        }
        var channel = channelLog[hoveringOverTab].channelName;
        if (options.channelsSettings.mutedChannels.indexOf(channel) === -1) {
            options.channelsSettings.mutedChannels.push(channel);
            saveOptions();
        }
        channelLog[hoveringOverTab].muted = true;
        updateChannelList(channelLog[hoveringOverTab]);
    });
    $(document).on("click", "#chTabCTMenuUnMute", function(){
        if (typeof hoveringOverTab === "undefined"){
            return;
        }
        var channel = channelLog[hoveringOverTab].channelName;
        var pos = options.channelsSettings.mutedChannels.indexOf(channel);
        if (pos !== -1) {
            options.channelsSettings.mutedChannels.splice(pos,1);
            saveOptions();
        }
        channelLog[hoveringOverTab].muted = false;
        updateChannelList(channelLog[hoveringOverTab]);
    });
    $(document).on("mouseover", ".channelTab", function(e){
        clearTimeout(hovering);
        var channelID       = $(this).attr("data-channel");
        hoveringOverTab     = channelID;
        if (!options.scriptSettings.preview){
            return;
        }
        var channelName     = channelLog[channelID].channelName;
        var channelPreviewWrapper = $("#channelPreviewWrapper");
        var channelTabHolder    = $(this);
        var cssOptions = {
            top: ($(this).offset().top + 25)+"px"
        };
        var previewContent = "There are no new messages in this channel!";
        if (channelLog[channelID].newMessages === true) {
            var previewMessages = [];
            $(".chc_"+channelID).each(function(i,e){
                if (i < channelLog[channelID].newMessagesCount){
                    previewMessages.push($(e).html());
                }
            });
            previewContent = previewMessages.join("<br>");
        }
        $("#channelPreviewMessages").html(previewContent);
        if ($(this).offset().left > $(document).width() / 2){
            cssOptions.left = ($(this).offset().left - channelPreviewWrapper.width() + 50)+"px";
        } else {
            cssOptions.left = ($(this).offset().left + 50)+"px";
        }
        channelPreviewWrapper
            .css(cssOptions)
            .children("h5")
            .text("'"+channelName+"' preview");
        if (options.scriptSettings.preview_reset){
            $("#CPAReset").show();
        } else {
            $("#CPAReset").hide();
        }
        if (options.scriptSettings.purge){
            $("#CPAPurge").show();
        } else {
            $("#CPAPurge").hide();
        }
        if (options.scriptSettings.channel_remove){
            $("#CPARemove").show();
        } else {
            $("#CPARemove").hide();
        }
    });
    $(document).on("mouseover", function(e){
        clearTimeout(hovering);
        if (typeof hoveringOverTab !== "undefined" && typeof channelLog[hoveringOverTab] !== "undefined") {
            var channelTab              = $("#channelTab" + hoveringOverTab);
            var channelPreviewWrapper   = $("#channelPreviewWrapper");
            var shouldShow              = channelLog[hoveringOverTab].newMessages === true;
            var OpenAndKeep             = $(e.target).closest(channelTab).length || $(e.target).closest(channelPreviewWrapper).length;
            var delay                   = OpenAndKeep ? 500 : 250;
            hovering = setTimeout(function(){
                if (options.scriptSettings.preview && OpenAndKeep && shouldShow) {
                    channelPreviewWrapper.show(0, function(){
                        if (chatDirection === "down") {
                            $("#channelPreviewContent").mCustomScrollbar("scrollTo",  "bottom");
                        }
                    });
                } else {
                    channelPreviewWrapper.hide();
                }
            }, delay);
        }
    });
    $(document).on("contextmenu", ".channelTab", function(e){
        e.preventDefault();
        var cssOptions = {
            top: e.pageY+"px"
        };
        if ($(this).offset().left > $(document).width() / 2){
            cssOptions.left = (e.pageX - $(this).width())+"px";
        } else {
            cssOptions.left = e.pageX+"px";
        }
        if (options.scriptSettings.preview_reset){
            $("#chTabCTMenuReset").show();
        } else {
            $("#chTabCTMenuReset").hide();
        }
        if (options.scriptSettings.purge){
            $("#chTabCTMenuPurge").show();
        } else {
            $("#chTabCTMenuPurge").hide();
        }
        if (options.scriptSettings.channel_remove){
            $("#chTabCTMenuRemove").show();
        } else {
            $("#chTabCTMenuRemove").hide();
        }
        if (options.channelsSettings.mutedChannels.indexOf(channelLog[hoveringOverTab].channelName) !== -1){
            $("#chTabCTMenuUnMute").show();
            $("#chTabCTMenuMute").hide();
        } else {
            $("#chTabCTMenuMute").show();
            $("#chTabCTMenuUnMute").hide();
        }
        if (hoveringOverTab.match(/^[a-z]+/i)) {
            $("#chTabCTMenuLeave").hide();
            if (hoveringOverTab.indexOf(MergedChannelsGroup) !== -1) {
                $("#chTabCTMenuColor").show();
            } else {
                $("#chTabCTMenuColor").hide();
            }
        } else {
            $("#chTabCTMenuColor").hide();
            $("#chTabCTMenuLeave").show();
        }
        if (scriptChannels.indexOf(hoveringOverTab) !== -1 && hoveringOverTab !== WhispersChannel) {
            $("#chTabCTMenuLast").hide();
        } else {
            $("#chTabCTMenuLast").show();
        }
        $("#channelTabContextMenu").css(cssOptions).show();
        $("#channelPreviewWrapper").hide();
        return false;
    });
    $(document).on("click", "#ToASettings", function(){
        $("#modalBackground").show();
        $("#ToASettingsWindow").show();
        loadAllChannels();
        /**
         * load muted channel
         */
        var mchw    = $("<span>").addClass("ChMChannelWrapper border2");
        var mchx    = $("<span>").addClass("ChMMChX ui-element fa fa-times ruby");
        $("#ToASChMMutedChannelsHolder").html("");
        $("#ToASChMMergedChannelsHolder").html("");
        $("#ToASChMMergedChannelsGroupsHolder").html("");
        var channelName = "";
        for (var i in options.channelsSettings.mutedChannels) {
            channelName = options.channelsSettings.mutedChannels[i];
            var holder      = mchw.clone().append(channelName).appendTo("#ToASChMMutedChannelsHolder");
            mchx.clone().attr("data-channel", channelName).prependTo(holder);
        }
        channelName = "";
        $("#ToASChMMergedChannelsGroupsHolder").html("");
        for (var j in options.channelsSettings.channelMerger.groups){
            var mcggn = options.channelsSettings.channelMerger.groups[j];
            addChannelGroup(j, mcggn);
        }
        for (var channelID in channelLog) {
            if (!channelID.match(/^[0-9]+$/)) {
                continue;
            }
            var channelInfo     = channelLog[channelID];
            channelName     = channelInfo.channelName;
            var channelBlob     = mchw.clone().attr("data-channel", channelName).text(channelName);
            if (typeof options.channelsSettings.channelMerger.mapping[channelName] !== "undefined") {
                var grouppedInto    = options.channelsSettings.channelMerger.mapping[channelName];
                var mcgGroupID      = options.channelsSettings.channelMerger.groups.indexOf(grouppedInto);
                mcgGroupID      = MergedChannelsGroup + "_MCGID_" + groupsMap[grouppedInto];
                if (options.channelsSettings.channelMerger.defaultChannels[grouppedInto] === channelName) {
                    channelBlob.insertAfter("#"+mcgGroupID+" > input");
                } else {
                    channelBlob.appendTo("#"+mcgGroupID);
                }
            } else {
                channelBlob.appendTo("#ToASChMMergedChannelsHolder");
            }
        }
        channelName = "";
        $(".incsort").sortable({
            items: "span",
            connectWith: ".incsort",
            receive: function(i,e) {
                channelName = $(e.item[0]).attr("data-channel");
                var groupName   = $(this).attr("data-group");
                if (typeof groupName === "undefined") {
                    delete options.channelsSettings.channelMerger.mapping[channelName];
                } else {
                    options.channelsSettings.channelMerger.mapping[channelName] = groupName;
                }
                saveOptions();
            },
            update: function(i,e){
                var groupName   = $(this).attr("data-group");
                if (typeof groupName !== "undefined") {
                    var channels = $(i.target).children("span");
                    var channelName = $(channels[0]).attr("data-channel");
                    options.channelsSettings.channelMerger.defaultChannels[groupName] = channelName;
                    saveOptions();
                } // else branch makes no sense :)
            }
        }).disableSelection();
    });
    $(document).on("click", ".ChMMChX", function(){
        var channel             = $(this).attr("data-channel");
        var channelID           = resolveChannelID(channel).cID;
        channelLog[channelID].muted  = false;
        updateChannelList(channelLog[channelID]);
        var pos = options.channelsSettings.mutedChannels.indexOf(channel);
        if (pos !== -1) {
            options.channelsSettings.mutedChannels.splice(pos,1);
        }
        $(this).parent().fadeOut("slow", function(){
            $(this).remove();
        });
        saveOptions();
    });
    $(document).on("click", ".joinChannel", function(){
        var chn = $(this).text().replace(/^,+|,+$/gm,"");
        $("#chatMessage").text("/join "+ chn);
        var pwd = $(this).parent().find(".jcPWD").text();
        $("#chatMessage").append(" " + pwd);
        if (options.scriptSettings.auto_join) {
            $("#chatSendMessage").click();
        }
    });
    $(document).on("click", function(e){
        $("#channelTabContextMenu").hide();
        var settings = $("#ToASettingsWindow");
        if (
            !$(e.target).closest("#ToASettingsWindow").length &&
            !$(e.target).closest("#ToASettings").length &&
            !$(e.target).closest("#confirmOverlay").length &&
            !$(e.target).closest(".replenishStamina").length ||
            $(e.target).closest("#ToASettingsWindowClose").length) {
            settings.hide();
            $("#ToASettingsChannelMerger").hide();
            $("#ToASettingsScriptSettings").hide();
            if ($(e.target).closest("#ToASettingsWindowClose").length) {
                $("#modalBackground").fadeOut();
            }
        }
    });
    $(document).on("click", "#ToAScriptOptions, #ToAChannelMerger", function(){
        var id = $(this).attr("id");
        if (id === "ToAScriptOptions") {
            $("#ToASettingsChannelMerger").slideUp(function(){
                $("#ToASettingsScriptSettings").slideDown();
            });
        } else {
            $("#ToASettingsScriptSettings").slideUp(function(){
                $("#ToASettingsChannelMerger").slideDown();
            });
        }
    });
    $(document).on("click", "#profileOptionQuickScope", quickScopeUser);
    $(document).on("click", "#profileOptionAt", mentionUser);
    $(document).on("click", "#profileOptionNick", nicknameUser);
    $(document).on("keydown", function(e){
        var keys = {
            Q: 81, // [Q]uickscope
            C: 67, // Ni[c]kname
            E: 69 // @m[e]ntion
        };
        var key = e.which;
        if ($("#profileOptionTooltip").css("display")==="block") {
            if (key === keys.Q) {
                quickScopeUser();
            } else if (key === keys.E) {
                mentionUser();
                e.preventDefault();
            } else if (key === keys.C) {
                nicknameUser();
            }
        }
    });
    $(document).on("change", ".ToASChMmcgName", updateGroupName);
    $(document).on("click", "#ToASChMAddGroup", function(){
        $.confirm({
            "title"     : "New Group Name",
            "message"   : "<input type=\"text\" id=\"ToASChMNewgroupName\" style=\"width:100%;\">",
            "buttons"   : {
                "Create"       : {
                    "class"     : "green",
                    "action"    : function() {
                        var groupName = $("#ToASChMNewgroupName").val();
                        if (groupName.match(/^\s*$/)){
                            groupName = randomName(7,13);
                        }
                        options.channelsSettings.channelMerger.groups.push(groupName);
                        groupsMap[groupName] = randomName(3,5) + "_" + randomInt(5,9);
                        $("#ToASettings").click();
                    }
                },
                "Cancel"       : {
                    "class"     : "red",
                    "action"    : function() {
                    }
                }
            }
        });
        $("#ToASChMNewgroupName").focus();
    });
    $(document).on("click", ".ToASChMChGRemove", function() {
        var elem = $(this);
        $.confirm({
            "title"     : "Group Delete Confirmation",
            "message"   : "Are you sure you want to remove this channel group?",
            "buttons"   : {
                "Yes"       : {
                    "class"     : "green",
                    "action"    : function() {
                        var groupID = elem.attr("data-gnid");
                        var groupName = options.channelsSettings.channelMerger.groups[groupID];
                        for (var x in options.channelsSettings.channelMerger.mapping) {
                            if (options.channelsSettings.channelMerger.mapping[x] === groupName) {
                                delete options.channelsSettings.channelMerger.mapping[x];
                            }
                        }
                        options.channelsSettings.channelMerger.groups.splice(groupID, 1);
                        var groupChannelID = MergedChannelsGroup + "_MCGID_" + groupsMap[groupName];
                        $("#channelTab"+groupChannelID).remove();
                        delete channelLog[groupChannelID];
                        delete groupsMap[groupName];
                        delete options.channelsSettings.channelMerger.defaultChannels[groupName];
                        $("#chatMessageList li").attr("class", "");
                        saveOptions();
                        $("#channelTabList > div:nth-child(2)").click();
                        loadMessages("reload");
                        $("#ToASettings").click();
                    }
                },
                "No"       : {
                    "class"     : "red",
                    "action"    : function() {
                    }
                }
            }
        });
    });
    function ChatTabs() {
        RoAModule.call(this, "Chat Tabs");
    }
    ChatTabs.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            init();
            RoAModule.prototype.load.apply(this);
        }
    });
    ChatTabs.prototype.constructor = ChatTabs;
    modules.chatTabs = new ChatTabs();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    const donatorColumns = ['.donator_list_crystals', '.donator_list_platinum', '.donator_list_gold', '.donator_list_food',
        '.donator_list_wood', '.donator_list_iron', '.donator_list_stone', '.donator_list_experience'];
    function parseClanDonationsPhp() {
        $('#toggleDonationPercent').attr("checked", false);
        for(var i = 0; i < donatorColumns.length; i++) {
            var total = 0;
            var column = $(donatorColumns[i]);
            column.each(function() { total += parseInt($(this).attr('title').replace(/,/g, '')); });
            column.each(function() { $(this).attr({ 'origFormat': $(this).text(), 'percFormat': (parseInt($(this).attr('title').replace(/,/g, ''))*100/total).toFixed(2) + " %" }); });
        }
    }
    function ClanDonations() {
        RoAModule.call(this, "Clan Donations");
    }
    ClanDonations.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function() {
            $('#myClanDonationTable').before($(template));
            $('#toggleDonationPercent').change(function() {
                var format = $(this).is(':checked') ? 'percFormat' : 'origFormat';
                for(var i = 0; i < donatorColumns.length; i++) {
                    $(donatorColumns[i]).each(function(){ $(this).text($(this).attr(format)); });
                }
            });
            modules.ajaxHooks.register("clan_donations.php", parseClanDonationsPhp);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.clanDonationPercent;
            this.continueLoad();
        }
    });
    ClanDonations.prototype.constructor = ClanDonations;
    modules.clanDonations = new ClanDonations();
})(modules.jQuery);

(function ($) {
    'use strict';
    var enabled = false;
    var autoToggleButton;
    var dungeonAutoActionTimer;
    function onAutoDungeon() {
        if(!enabled) {
            return;
        }
        continueAuto();
    }
    function continueAutoBattle() {
        modules.session.dungeonNeedsUpdate = true;
        var action = modules.createAutomateAction(modules.automateActionTypes.JQueryClick);
        action.control = '#dungeonEnemyList';
        action.findClause = '.dungeon_fight';
        modules.automateControl.add(action);
    }
    function continueAutoSearch() {
        modules.session.dungeonNeedsUpdate = true;
        var action = modules.createAutomateAction(modules.automateActionTypes.JQueryClick);
        action.control = '#dungeonSearch';
        modules.automateControl.add(action);
    }
    function createMoveAction(direction) {
        var action = modules.createAutomateAction(modules.automateActionTypes.JQueryClick);
        action.control = '#dungeonNavigation';
        action.findClause = '[data-direction="'+ direction.stringValue +'"]';
        modules.automateControl.add(action);
    }
    function continueAutoMove(roomData) {
        var availableUnexploredDirection = -1;
        for(var i = 0; i < 4; i++) {
            if(roomData.m[i] && !roomData.ml[i]) {
                availableUnexploredDirection = i;
                break;
            }
        }
        if(availableUnexploredDirection >= 0) {
            var directionToMove = modules.dungeonDirections.parseInt(availableUnexploredDirection);
            modules.session.dungeonNeedsUpdate = true;
            modules.logger.log("Dungeon Auto: Moving to unexplored cell on " + directionToMove.key);
            createMoveAction(directionToMove);
            return;
        }
        var path = findTargetRoom(FindCondition.UnexploredNeighbor);
        if(path && path.length > 0) {
            modules.session.dungeonNeedsUpdate = true;
            for(var i = 0; i < path.length; i++) {
                var step = path[i];
                createMoveAction(modules.dungeonDirections.parseInt(step.dir));
            }
            var action = modules.createAutomateAction(modules.automateActionTypes.Delay);
            action.time = 500;
            modules.automateControl.add(action);
        } else {
            modules.logger.warn("Could not find Backtrack path!");
            enabled = false;
        }
    }
    var FindCondition = {
        UnexploredNeighbor: 0,
        Exit: 1,
        Id: 2
    };
    function constructPath(cameFrom, currentId) {
        var path = [];
        while (cameFrom[currentId]) {
            var dir = modules.dungeonDirections.parseInt(cameFrom[currentId].dir);
            path.push({to: cameFrom[currentId].id, dir: dir.id});
            console.log(dir.key + " -> " + currentId);
            currentId = cameFrom[currentId].id;
        }
        path = path.reverse();
        return path;
    }
    function findTargetRoom(condition, param) {
        var openSet = [modules.settings.settings.dungeonData.currentRoomId];
        var closedSet = [];
        var cameFrom = {};
        var score = {};
        score[modules.settings.settings.dungeonData.currentRoomId] = 0;
        var maxIter = 300;
        var currIter = 0;
        while (openSet.length > 0) {
            currIter++;
            if(currIter >= maxIter) {
                console.error("findTargetRoom exceeded max iterations!");
                return;
            }
            var current = modules.settings.settings.dungeonData.rooms[openSet.pop()];
            switch (condition) {
                case FindCondition.UnexploredNeighbor: {
                    for(var i = 0; i < 4; i++) {
                        if(current.m[i] === 1 && !current.ml[i]) {
                            return constructPath(cameFrom, current.id);
                        }
                    }
                    break;
                }
                case FindCondition.Exit: {
                    if(current.m[4] === 1) {
                        return constructPath(cameFrom, current.id);
                    }
                    break;
                }
                case FindCondition.Id: {
                    if(current.id === param) {
                        return constructPath(cameFrom, current.id);
                    }
                    break;
                }
            }
            closedSet.push(current.id);
            for (var i = 0; i < 4; i++) {
                if(current.m[i] === 0 || !current.ml[i] || closedSet.includes(current.ml[i]) || openSet.includes(current.ml[i])) {
                    continue;
                }
                openSet.push(current.ml[i]);
                cameFrom[current.ml[i]] = {id: current.id, dir: i};
            }
        }
    }
    function continueAuto() {
        if(!modules.automateControl.isIdle()) {
            console.log("DA: Waiting for AutomateControl");
            return;
        }
        if(modules.session.dungeonNeedsUpdate) {
            console.log("DA: dungeonNeedUpdate");
            return;
        }
        if(!modules.settings.settings.dungeonData.currentRoomId) {
            console.log("DA: room unknown");
            return;
        }
        var roomData = modules.settings.settings.dungeonData.rooms[modules.settings.settings.dungeonData.currentRoomId];
        if(roomData.e.length > 0) {
            continueAutoBattle();
            return;
        }
        if(roomData.s) {
            continueAutoSearch();
            return;
        }
        continueAutoMove(roomData);
    }
    function toggleAuto() {
        enabled = !enabled;
        updateToggleText();
        modules.automateControl.clear();
    }
    function updateToggleText() {
        var text = enabled ? "On" : "Off";
        autoToggleButton.text("Auto " + text);
    }
    function DungeonAutomate() {
        RoAModule.call(this, "Dungeon Automate");
        this.addDependency("dungeonTracker");
    }
    DungeonAutomate.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            if(!this.checkDependencies()) {
                return;
            }
            autoToggleButton = $('<a></a>');
            autoToggleButton.click(toggleAuto);
            updateToggleText();
            var wrapper = $('<div class="bt1 mt10 center"></div>');
            wrapper.append(autoToggleButton);
            $('#dungeonInfo').append(wrapper);
            var manualContinueButton = $('<a>(A) Next</a>');
            manualContinueButton.click(continueAuto);
            var wrapper = $('<div class="bt1 mt10 center"></div>');
            wrapper.append(manualContinueButton);
            $('#dungeonInfo').append(wrapper);
            dungeonAutoActionTimer = modules.createInterval("DungeonAutoAction");
            dungeonAutoActionTimer.set(onAutoDungeon, 200);
            /*modules.ajaxHooks.register("dungeon_leave.php", onDungeonLeave);
            modules.ajaxHooks.register("dungeon_info.php", onDungeonInfo);
            modules.ajaxHooks.register("dungeon_search.php", onDungeonSearch);
            modules.ajaxHooks.register("dungeon_move.php", onDungeonMove);
            modules.ajaxHooks.register("dungeon_battle.php", onDungeonBattle);*/
            RoAModule.prototype.load.apply(this);
        }
    });
    DungeonAutomate.prototype.constructor = DungeonAutomate;
    modules.dungeonAutomate = new DungeonAutomate();
})(modules.jQuery);

(function () {
    function DungeonDirectionMap() {
        this.addDirection(new DungeonDirection("East", 0, "east", 2));
        this.addDirection(new DungeonDirection("North", 1, "north", 3));
        this.addDirection(new DungeonDirection("West", 2, "west", 0));
        this.addDirection(new DungeonDirection("South", 3, "south", 1));
        this.rebuildOpposites();
    }
    DungeonDirectionMap.prototype = Object.spawn(RoAModule.prototype, {
        directions: {},
        addDirection: function (direction) {
            if(this.directions[direction.key]) {
                console.error("Dungeon Direction already defined: " + direction.key);
            }
            this.directions[direction.key] = direction;
        },
        parseInt: function (int) {
            for (var key in this.directions) {
                var direction = this.directions[key];
                if (direction.id == int) {
                    return direction;
                }
            }
            console.warn("Unknown Movement Direction: " + int);
        },
        parse: function (str, matchInclude) {
            matchInclude = matchInclude || false;
            for (var key in this.directions) {
                var direction = this.directions[key];
                if(direction.stringValue == str) {
                    return direction;
                } else if (matchInclude && str.includes(direction.stringValue)) {
                    return direction;
                }
            }
            console.warn("Unknown Movement Direction: " + str);
        },
        rebuildOpposites: function () {
            for (var key in this.directions) {
                this.directions[key].opposite = this.parseInt(this.directions[key].oppositeId);
            }
        }
    });
    DungeonDirectionMap.prototype.constructor = DungeonDirectionMap;
    function DungeonDirection(key, id, stringValue, oppositeId) {
        this.name = "DIR_" + key;
        this.key = key;
        this.id = id;
        this.stringValue = stringValue;
        this.oppositeId = oppositeId;
    }
    DungeonDirection.prototype = Object.spawn(RoAModule.prototype, {
        key: null,
        id: null,
        stringValue: "",
        opposite: null,
        oppositeId: null
    });
    DungeonDirection.prototype.constructor = DungeonDirection;
    modules.dungeonDirections = new DungeonDirectionMap();
})();

(function ($) {
    'use strict';
    var dmc, dmctx, dmv;
    var initialize = function () {
        console.log("Resetting Dungeon Map");
        modules.settings.dungeonMap = { r:{}, cf:0, ct:null, v: modules.constants.DungeonMapVersion, hasData: false };
    };
    function onLeaveDungeon() {
        initialize();
    }
    function onUpdateDungeonVisibility(requestData) {
        if(requestData.url.indexOf("dungeon_") === -1) {
            $("#dMCW").hide();
        } else if (modules.settings.dungeonMap.hasData) {
            $("#dMCW").show();
        }
    }
    function onUpdateDungeon(requestData) {
        if (requestData.json.hasOwnProperty("data") && requestData.json.data.hasOwnProperty("map")) {
            modules.settings.dungeonMap.hasData = true;
            if (modules.settings.dungeonMap.cf !== requestData.json.data.floor) {
                modules.settings.dungeonMap.r = {};
                modules.settings.dungeonMap.cf = requestData.json.data.floor;
            }
            var jrd = requestData.json.data;
            var data = {};
            var token = $(jrd.map).text().replace("↓", "v"); // map
            token = btoa(JSON.stringify(token)); // token
            if (modules.settings.dungeonMap.r.hasOwnProperty(token)) {
                data = JSON.parse(JSON.stringify(modules.settings.dungeonMap.r[token]));
            } else {
                data.pe = "";
                data.ps = "";
                data.pn = "";
                data.pw = "";
                data.t  = token;
            }
            if (modules.settings.dungeonMap.ct === null) {
                modules.settings.dungeonMap.ct = token;
            }
            data.e = jrd.e?1:0; // east
            data.s = jrd.s?1:0; // south
            data.n = jrd.n?1:0; // north
            data.w = jrd.w?1:0; // west
            data.r = !!jrd.search; // raided
            data.b = Object.keys(jrd.enemies).length; // battles available
            modules.settings.dungeonMap.r[data.t] = data;
            var walk = requestData.json.hasOwnProperty("m") && requestData.json.m.match(/You walked (east|south|north|west)/);
            walk = walk ? requestData.json.m.match(/You walked (east|south|north|west)/) : false;
            if (walk !== false) {
                walk = walk[1].match(/^./)[0];
                if (modules.settings.dungeonMap.ct !== data.t) {
                    if (typeof modules.settings.dungeonMap.r[modules.settings.dungeonMap.ct] !== "undefined") {
                        modules.settings.dungeonMap.r[modules.settings.dungeonMap.ct]["p"+walk] = data.t;
                        var sm = {
                            "s": "n",
                            "n": "s",
                            "e": "w",
                            "w": "e"
                        };
                        modules.settings.dungeonMap.r[data.t]["p"+sm[walk]] = modules.settings.dungeonMap.ct;
                    }
                    modules.settings.dungeonMap.ct = data.t;
                }
            }
            modules.settings.save();
            updateDungeonMap();
        }
    }
    function onResizeEnd(e) {
        $("#dungeonMapCanvas").attr({width: modules.settings.dungeonMap.size.width, height: modules.settings.dungeonMap.size.height});
        updateDungeonMap(false);
    }
    function updateDungeonMap() {
        if ($("#dungeonMapCanvas").length === 0) {
            var h = $("<div>")
                .attr("id", "dMCW")
                .css({position:"absolute",top:0,left:0})
                .addClass("border2 ui-component")
                .appendTo("body");
            $("<canvas>").attr({
                id: "dungeonMapCanvas",
                width: "325",
                height: "325"
            }).appendTo("#dMCW");
            h.draggable({handle:"#dungeonMapCanvas"}).resizable({stop: onResizeEnd});
            dmc = document.getElementById("dungeonMapCanvas");
            dmctx = dmc.getContext("2d");
        }
        dmv = [];
        dmctx.clearRect(0,0,dmc.width,dmc.height);
        drawTile(modules.settings.dungeonMap.ct, Math.floor(dmc.width/2), Math.floor(dmc.height/2), 1);
    }
    function drawTile(id, x, y, player) {
        if (typeof player === "undefined") {
            player = 0;
        }
        if (dmv.indexOf(id) !== -1) {
            return;
        }
        var tile = modules.settings.dungeonMap.r[id];
        dmv.push(id);
        dmctx.fillStyle = "#333";
        dmctx.fillRect(x-4, y-4, 10, 10);
        drawTileWall(x,y,"top", !tile.n);
        drawTileWall(x,y,"left", !tile.w);
        drawTileWall(x,y,"right", !tile.e);
        drawTileWall(x,y,"bot", !tile.s);
        if (tile.r) {
            dmctx.fillStyle     = modules.constants.DungeonRoomSearchedColor;
            dmctx.strokeStyle   = modules.constants.DungeonRoomSearchedColor;
            dmctx.arc(x,y,2, 0, 2*Math.PI);
            dmctx.fill();
        }
        if (tile.b > 0) {
            dmctx.fillStyle     = modules.constants.DungeonRoomHasEnemiesColor;
            dmctx.strokeStyle   = modules.constants.DungeonRoomHasEnemiesColor;
            dmctx.arc(x,y,2, 0, 2*Math.PI);
            dmctx.fill();
        }
        if (player === 1) {
            dmctx.fillStyle     = modules.constants.DungeonPlayerColor;
            dmctx.strokeStyle   = modules.constants.DungeonPlayerColor;
            dmctx.arc(x,y,2, 0, 2*Math.PI);
            dmctx.fill();
        }
        if (tile.n === 1 && tile.pn !== "") {
            drawTile(tile.pn, x, y-10);
        }
        if (tile.w === 1 && tile.pw !== "") {
            drawTile(tile.pw, x-10, y);
        }
        if (tile.e === 1 && tile.pe !== "") {
            drawTile(tile.pe, x+10, y);
        }
        if (tile.s === 1 && tile.ps !== "") {
            drawTile(tile.ps, x, y+10);
        }
    }
    function drawTileWall(x,y,which, blocked) {
        if (blocked) {
            dmctx.strokeStyle = modules.constants.DungeonWallColor;
            dmctx.fillStyle   = "#ffffff";
        } else {
            dmctx.strokeStyle = "#333";
            return;
        }
        dmctx.beginPath();
        if (which === "top") {
            dmctx.moveTo(x-5, y-5);
            dmctx.lineTo(x+5, y-5);
        } else if (which === "left") {
            dmctx.moveTo(x-5, y-5);
            dmctx.lineTo(x-5, y+5);
        } else if (which === "right") {
            dmctx.moveTo(x+5, y+5);
            dmctx.lineTo(x+5, y-5);
        } else if (which === "bot") {
            dmctx.moveTo(x-5, y+5);
            dmctx.lineTo(x+5, y+5);
        }
        dmctx.stroke();
        dmctx.closePath();
    }
    function DungeonMap() {
        RoAModule.call(this, "Dungeon Map");
        this.addDependency("dungeonTracker");
    }
    DungeonMap.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            if(!this.checkDependencies()) {
                return;
            }
            if(modules.settings.dungeonMap == null) {
                initialize();
            } else {
                try {
                    if(modules.settings.dungeonMap == null || modules.settings.dungeonMap.v == null || modules.settings.dungeonMap.v != modules.constants.DungeonMapVersion)
                    {
                        initialize();
                    }
                } catch (e) {
                    initialize();
                }
            }
            modules.ajaxHooks.register("dungeon_leave.php", onLeaveDungeon);
            modules.ajaxHooks.register("dungeon_info.php", onUpdateDungeon);
            modules.ajaxHooks.register("dungeon_move.php", onUpdateDungeon);
            modules.ajaxHooks.register("dungeon_search.php", onUpdateDungeon);
            modules.ajaxHooks.registerAll(onUpdateDungeonVisibility);
            RoAModule.prototype.load.apply(this);
        }
    });
    DungeonMap.prototype.constructor = DungeonMap;
    modules.dungeonMap = new DungeonMap();
})(modules.jQuery);

(function () {
    const DungeonDataVersion = 3;
    function onDungeonInfo(requestData) {
        if (!requestData.json.data) {
            return;
        }
        var roomData;
        if(modules.settings.settings.dungeonData.currentRoomId) {
            roomData = modules.settings.settings.dungeonData.rooms[modules.settings.settings.dungeonData.currentRoomId];
        }
        var moveEast = requestData.json.data.e;
        var moveNorth = requestData.json.data.n;
        var moveSouth = requestData.json.data.s;
        var moveWest = requestData.json.data.w;
        var moveDown = requestData.json.data.d;
        var canSearch = requestData.json.data.search;
        if(moveDown) {
            modules.settings.settings.dungeonData.exitRoom = roomData.id;
        }
        var moveFlags = [ moveEast ? 1 : 0, moveNorth ? 1 : 0, moveWest ? 1 : 0, moveSouth ? 1 : 0, moveDown ? 1 : 0 ];
        var enemyData = [];
        for(var num in requestData.json.data.enemies) {
            enemyData.push(requestData.json.data.enemies[num].id);
        }
        if(!roomData) {
            modules.settings.settings.dungeonData.currentRoomId = modules.settings.settings.dungeonData.nextRoomId++;
            var moveLinks = [ null, null, null, null ];
            roomData = { id: modules.settings.settings.dungeonData.currentRoomId, m: moveFlags, ml: moveLinks, e: enemyData, s: canSearch, x: true };
        } else {
            roomData.m = moveFlags;
            roomData.e = enemyData;
            roomData.s = canSearch;
        }
        roomData.pos = [modules.settings.settings.dungeonData.position[0], modules.settings.settings.dungeonData.position[1]];
        modules.settings.settings.dungeonData.rooms[roomData.id] = roomData;
        modules.session.dungeonNeedsUpdate = false;
    }
    function onDungeonSearch(requestData) {
        onDungeonInfo(requestData);
    }
    function onDungeonLeave(requestData) {
        initializeDungeonData();
    }
    function onDungeonMove(requestData) {
        if(!requestData.json) {
            initializeDungeonData();
            modules.session.dungeonNeedsUpdate = true;
            return;
        }
        var previousRoomId = modules.settings.settings.dungeonData.currentRoomId;
        var direction = modules.dungeonDirections.parse(requestData.json.m, true);
        var previousRoomData = modules.settings.settings.dungeonData.rooms[previousRoomId];
        if (previousRoomData.ml[direction.id]) {
            modules.settings.settings.dungeonData.currentRoomId = previousRoomData.ml[direction.id];
        } else {
            modules.settings.settings.dungeonData.currentRoomId = null;
        }
        adjustPosition(direction);
        onDungeonInfo(requestData);
        previousRoomData.ml[direction.id] = modules.settings.settings.dungeonData.currentRoomId;
        modules.settings.settings.dungeonData.rooms[modules.settings.settings.dungeonData.currentRoomId].ml[direction.opposite.id] = previousRoomId;
    }
    function onDungeonBattle(requestData) {
    }
    function initializeDungeonData() {
        modules.settings.settings.dungeonData = {
            rooms: {},
            nextRoomId: 1,
            exitRoom: null,
            version: DungeonDataVersion,
            position: [0, 0],
        };
    }
    function adjustPosition(direction, count) {
        var steps = count || 1;
        if (direction === modules.dungeonDirections.directions.North) {
            modules.settings.settings.dungeonData.position[1] += steps;
        } else if (direction === modules.dungeonDirections.directions.South) {
            modules.settings.settings.dungeonData.position[1] -= steps;
        } else if (direction === modules.dungeonDirections.directions.East) {
            modules.settings.settings.dungeonData.position[0] += steps;
        } else if (direction === modules.dungeonDirections.directions.West) {
            modules.settings.settings.dungeonData.position[0] -= steps;
        }
    }
    function DungeonTracker() {
        RoAModule.call(this, "Dungeon Tracker");
    }
    DungeonTracker.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            if (!modules.settings.settings.dungeonData || modules.settings.settings.dungeonData.version != DungeonDataVersion) {
                initializeDungeonData();
            }
            modules.ajaxHooks.register("dungeon_leave.php", onDungeonLeave);
            modules.ajaxHooks.register("dungeon_info.php", onDungeonInfo);
            modules.ajaxHooks.register("dungeon_search.php", onDungeonSearch);
            modules.ajaxHooks.register("dungeon_move.php", onDungeonMove);
            modules.ajaxHooks.register("dungeon_battle.php", onDungeonBattle);
            RoAModule.prototype.load.apply(this);
        }
    });
    DungeonTracker.prototype.constructor = DungeonTracker;
    modules.dungeonTracker = new DungeonTracker();
})();

(function ($) {
    'use strict';
    var template;
    var wnd;
    function onClick() {
        wnd.toggle();
    }
    function DungeonWindow() {
        RoAModule.call(this, "Dungeon Window");
    }
    DungeonWindow.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#dungeonWindowTitle"});
            wnd.resizable();
            wnd.hide();
            $('#dungeonWindowClose').click(function () {
                wnd.hide();
            });
            modules.uiScriptMenu.addLink("Dungeon", onClick);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.dungeonWindow;
            this.continueLoad();
        }
    });
    DungeonWindow.prototype.constructor = DungeonWindow;
    modules.dungeonWindow = new DungeonWindow();
})(modules.jQuery);

modules.templates = {
	chartWindow: '<div id="gameCharts" class="border2 ui-component chartWindow">     <div id="gameChartWindow" class="ui-element border2" style="height: 100%">         <h5 id="gameChartTitle" class="center toprounder">Charts</h5>         <span class="closeModal"><a id="gameChartWindowClose">×</a></span>         <div id="gameChartContent" class="mCSB_container" style="height: 100%">             <div id="gameChartControls" class="col-xs-12 col-md-12 center mt10" style="display: block">                 <div id="gameChartReset" class="btn btn-primary">Reset</div>                 <div id="gameChartRedraw" class="btn btn-primary">Redraw</div>                 <div id="gameChartDebugData" class="btn btn-primary">Debug</div>                 <div id="gameChartTimeMinute" class="btn btn-primary">Minute</div>                 <div id="gameChartTimeHour" class="btn btn-primary">Hour</div>                 <div id="gameChartTimeDay" class="btn btn-primary">Day</div>                 <div id="gameChartTimeMonth" class="btn btn-primary">Month</div>                 <div id="gameChartStorageSizeWrapper" style="display: inline-block">                     <span>Storage Size: </span>                     <span id="gameChartStorageSize">0</span>                     <span>bytes</span>                 </div>             </div>             <div id="gameChartCategoryTabs" style="height: 100%">                 <div class="col-xs-12 col-md-12 mt10" style="display: block">                     <div id="toggleGameChartPlayer" class="btn btn-primary">Player Charts</div>                     <div id="toggleGameChartStats" class="btn btn-primary">Game Stats</div>                     <div id="toggleGameChartMarket" class="btn btn-primary">Market</div>                 </div>                 <div id="gameChartPlayerTabs" class="chartCategoryTab">                     <div class="col-xs-12 col-md-12 mt10" style="display: block">                         <div id="toggleChartPlayerBattleXP" class="btn btn-primary">Battle XP</div>                         <div id="toggleChartPlayerHarvestXP" class="btn btn-primary">Harvest XP</div>                         <div id="toggleChartPlayerCraftingXP" class="btn btn-primary">Crafting XP</div>                         <div id="toggleChartPlayerGold" class="btn btn-primary">Gold</div>                         <div id="toggleChartPlayerGoldLooted" class="btn btn-primary">Gold Looted</div>                         <div id="toggleChartPlayerPlatinum" class="btn btn-primary">Platinum</div>                         <div id="toggleChartPlayerCrystal" class="btn btn-primary">Crystals</div>                         <div id="toggleChartPlayerMaterial" class="btn btn-primary">Material</div>                         <div id="toggleChartPlayerFragment" class="btn btn-primary">Fragments</div>                         <div id="toggleChartPlayerFood" class="btn btn-primary">Food</div>                         <div id="toggleChartPlayerWood" class="btn btn-primary">Wood</div>                         <div id="toggleChartPlayerIron" class="btn btn-primary">Iron</div>                         <div id="toggleChartPlayerStone" class="btn btn-primary">Stone</div>                     </div>                     <div id="chartPlayerBattleXP" class="chartTab"></div>                     <div id="chartPlayerHarvestXP" class="chartTab"></div>                     <div id="chartPlayerCraftingXP" class="chartTab"></div>                     <div id="chartPlayerGold" class="chartTab"></div>                     <div id="chartPlayerGoldLooted" class="chartTab"></div>                     <div id="chartPlayerPlatinum" class="chartTab"></div>                     <div id="chartPlayerCrystal" class="chartTab"></div>                     <div id="chartPlayerMaterial" class="chartTab"></div>                     <div id="chartPlayerFragment" class="chartTab"></div>                     <div id="chartPlayerFood" class="chartTab"></div>                     <div id="chartPlayerWood" class="chartTab"></div>                     <div id="chartPlayerIron" class="chartTab"></div>                     <div id="chartPlayerStone" class="chartTab"></div>                 </div>                 <div id="gameChartStatsTabs" class="chartCategoryTab">                     <div class="col-xs-12 col-md-12 mt10" style="display: block">                         <div id="toggleChartMonsterSlain" class="btn btn-primary">Monsters Slain</div>                         <div id="toggleChartGoldLooted" class="btn btn-primary">Gold Looted</div>                         <div id="toggleChartGoldInGame" class="btn btn-primary">Gold in Game</div>                         <div id="toggleChartResourcesInGame" class="btn btn-primary">Resources in Game</div>                         <div id="toggleChartPlatinumInGame" class="btn btn-primary">Platinum in Game</div>                         <div id="toggleChartMaterialInGame" class="btn btn-primary">Material in Game</div>                         <div id="toggleChartFragmentInGame" class="btn btn-primary">Fragments in Game</div>                         <div id="toggleChartHarvests" class="btn btn-primary">Harvests</div>                         <div id="toggleChartResourcesHarvested" class="btn btn-primary">Resources Harvested</div>                         <div id="toggleChartItemsFound" class="btn btn-primary">Items Found</div>                     </div>                     <div id="chartMonsterSlain" class="chartTab"></div>                     <div id="chartGoldLooted" class="chartTab"></div>                     <div id="chartGoldInGame" class="chartTab"></div>                     <div id="chartResourcesInGame" class="chartTab"></div>                     <div id="chartPlatinumInGame" class="chartTab"></div>                     <div id="chartMaterialInGame" class="chartTab"></div>                     <div id="chartFragmentInGame" class="chartTab"></div>                     <div id="chartHarvests" class="chartTab"></div>                     <div id="chartResourcesHarvested" class="chartTab"></div>                     <div id="chartItemsFound" class="chartTab"></div>                 </div>                 <div id="gameChartMarketTabs" class="chartCategoryTab">                     <div class="col-xs-12 col-md-12 mt10" style="display: block">                         <div id="toggleChartMarketCrystals" class="btn btn-primary">Crystals</div>                         <div id="toggleChartMarketPlatinum" class="btn btn-primary">Platinum</div>                         <div id="toggleChartMarketFood" class="btn btn-primary">Food</div>                         <div id="toggleChartMarketWood" class="btn btn-primary">Wood</div>                         <div id="toggleChartMarketIron" class="btn btn-primary">Iron</div>                         <div id="toggleChartMarketStone" class="btn btn-primary">Stone</div>                         <div id="toggleChartMarketMaterial" class="btn btn-primary">Material</div>                         <div id="toggleChartMarketFragment" class="btn btn-primary">Fragments</div>                     </div>                     <div id="chartMarketCrystals" class="chartTab"></div>                     <div id="chartMarketPlatinum" class="chartTab"></div>                     <div id="chartMarketFood" class="chartTab"></div>                     <div id="chartMarketWood" class="chartTab"></div>                     <div id="chartMarketIron" class="chartTab"></div>                     <div id="chartMarketStone" class="chartTab"></div>                     <div id="chartMarketMaterial" class="chartTab"></div>                     <div id="chartMarketFragment" class="chartTab"></div>                 </div>             </div>         </div>     </div> </div>',
	clanDonationPercent: '<label style="display: block; padding-left: 15px; text-indent: -15px; margin-top:-25px">     <input type="checkbox" id="toggleDonationPercent" style="width: 13px; height: 13px; padding: 0; margin: 0; vertical-align: bottom; position: relative; top: -3px; *overflow: hidden;" />     Show % </label>',
	debugWindow: '<div id="debug" class="border2 ui-component debugWindow">     <div id="debugWindow" class="ui-element border2" style="height: 100%">         <h5 id="debugWindowTitle" class="center toprounder">Debug</h5>         <span class="closeModal"><a id="debugWindowClose">×</a></span>         <div id="debugWindowContent" class="mCSB_container" style="height: 100%">             <table class="avi" style="margin:auto">                 <thead>                 <tr>                     <th colspan="3">                         Request History                     </th>                 </tr>                 <tr>                     <th>Url</th>                     <th>Time</th>                     <th>Data Sent</th>                     <th>Data Received</th>                 </tr>                 </thead>                 <tbody id="debugWindowContentBody">                 </tbody>             </table>         </div>     </div> </div>',
	dungeonWindow: '<div id="roaDungeon" class="border2 ui-component dungeonWindow">     <div id="dungeonWindow" class="ui-element border2" style="height: 100%">         <h5 id="dungeonWindowTitle" class="center toprounder">Dungeon</h5>         <span class="closeModal"><a id="dungeonWindowClose">×</a></span>         <div id="dungeonWindowContent" class="mCSB_container" style="height: 100%">         </div>     </div> </div>',
	noteWindow: '<div id="notes" class="border2 ui-component noteWindow">     <div id="noteWindow" class="ui-element border2" style="height: 100%">         <h5 id="noteTitle" class="center toprounder">Notes</h5>         <span class="closeModal"><a id="noteWindowClose">×</a></span>         <div id="noteContent" class="mCSB_container" style="height: 100%">             <div id="noteEditor"></div>         </div>     </div> </div>',
	playerGainWindow: '<div id="roaPlayerGains" class="border2 ui-component gainWindow">     <div id="gainWindow" class="ui-element border2" style="height: 100%">         <h5 id="gainWindowTitle" class="center toprounder">Gains</h5>         <span class="closeModal"><a id="gainWindowClose">×</a></span>         <div id="gainWindowContent" class="mCSB_container" style="height: 100%">         </div>     </div> </div>',
	scriptMenu: '<div id="roaext" style="margin-bottom: 10px">     <div class="ui-element border2">         <h5 id="roaMenuTitle" class="toprounder center active"></h5>         <ul id="roaMenuContent">         </ul>     </div> </div>',
	settingsWindow: '<div id="roaSettings" class="border2 ui-component settingsWindow">     <div id="settingsWindow" class="ui-element border2" style="height: 100%">         <h5 id="settingsWindowTitle" class="center toprounder">Settings</h5>         <span class="closeModal"><a id="settingsWindowClose">×</a></span>         <div id="settingsWindowContent" class="mCSB_container" style="height: 100%">         </div>     </div> </div>',
	timerEditor: '<div id="timerEditor" class="border2 ui-component timerEditorWindow">     <div id="timerEditorWindow" class="ui-element border2" style="height: 100%">         <h5 id="timerEditorTitle" class="center toprounder">Create Timer</h5>         <span class="closeModal"><a id="timerEditorWindowClose">×</a></span>         <div id="timerEditorContent" class="mCSB_container" style="height: 100%">             <div id="activeCustomTimers">                 <table class="avi" style="margin:auto">                     <thead>                     <tr>                         <th colspan="3">                             Active Timers                         </th>                     </tr>                     <tr>                         <th>Name</th>                         <th>Time</th>                         <th>Options</th>                     </tr>                     </thead>                     <tbody id="activeCustomTimerTableContent">                     </tbody>                 </table>             </div>             <div id="createNewCustomTimer" style="margin-top: 10px">                 <table class="avi" style="margin:auto">                     <tr>                         <th>                             <input id="customTimerOptName" class="createTimerInput"> Name</input>                         </th>                         <th>                             <input id="customTimerOptHour" class="createTimerInputTime" maxlength="2"> H</input>                             <input id="customTimerOptMinute" class="createTimerInputTime" maxlength="2"> M</input>                             <input id="customTimerOptSecond" class="createTimerInputTime" maxlength="2"> S</input>                         </th>                         <th>                             <input id="customTimerOptSound" type="checkbox" class="createTimerCheckbox">Sound</input>                             <input id="customTimerOptNotify" type="checkbox" class="createTimerCheckbox">Notification</input>                         </th>                         <th>                             <a id="customTimerCreateButton">Create</a>                         </th>                     </tr>                 </table>             </div>             <div id="createTimerFeedback" class="createTimerFeedback">             </div>         </div>     </div> </div>',
	timerMenu: '<div id="timerMenu" style="margin-top: 10px">     <div class="ui-element border2">         <h5 class="toprounder center"><a id="timerEditorOpen" href="javascript:;" style="text-decoration: none!important;">Timers</a></h5>         <div id="timerMenuContents" class="row">         </div>     </div> </div>'
};

(function () {
    'use strict';
    const ConstructionKey = "Construction";
    const HarvestronKey = "Harvestron";
    var lastMessage;
    var houseTimers = {};
    function clearHouseTimers() {
        for(var key in houseTimers) {
            if(houseTimers[key].ended) {
                houseTimers[key].delete();
                delete houseTimers[key];
            }
        }
    }
    function updateHouseStatus(requestData) {
        clearHouseTimers();
        var text = requestData.json.m;
        if (text === lastMessage) {
            return;
        }
        if (text.indexOf("available again") !== -1) { // Working
            var constructionTime = modules.utils.parseTimeStringLong(text) / 1000;
            setHouseTimer(ConstructionKey, constructionTime);
        }
    }
    function updateHarvestronStatus(requestData) {
        var time = parseInt(requestData.json.m.search(/([0-9]+)\sminute/i));
        if(!time) {
            return;
        }
        setHouseTimer(HarvestronKey, time * 60);
    }
    function setHouseTimer(key, value) {
        if(!houseTimers[key]) {
            houseTimers[key] = modules.createUITimer(key);
            houseTimers[key].sound = modules.settings.settings.notification.house.sound;
            houseTimers[key].notify = modules.settings.settings.notification.house.show;
        }
        houseTimers[key].set(value);
        houseTimers[key].resume();
    }
    function updateHouseTimers(requestData) {
        clearHouseTimers();
        if(!requestData.json.p || !requestData.json.p.house_timers || requestData.json.p.house_timers.length <= 0) {
            return;
        }
        for (var i = 0; i < requestData.json.p.house_timers.length; i++) {
            var key = requestData.json.p.house_timers[i].n;
            var value = requestData.json.p.house_timers[i].next;
            setHouseTimer(key, value);
        }
    }
    function HouseMonitor() {
        RoAModule.call(this, "House Monitor");
    }
    HouseMonitor.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            modules.ajaxHooks.register("house.php", updateHouseStatus);
            modules.ajaxHooks.register("house_harvest_job.php", updateHarvestronStatus);
            modules.ajaxHooks.registerAutoSend("house.php", {}, modules.constants.HouseUpdateInterval);
            modules.ajaxRegisterAutoActions(updateHouseTimers);
            RoAModule.prototype.load.apply(this);
        }
    });
    HouseMonitor.prototype.constructor = HouseMonitor;
    modules.houseMonitor = new HouseMonitor();
})();

(function ($) {
    'use strict';
    function UIActionShortcuts() {
        RoAModule.call(this, "UI Action Shortcuts");
    }
    UIActionShortcuts.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            var $menuLink = $('#roaMenu');
            var $appends = {
                battle: $("<a href='javascript:;' data-delegate-click='#loadMobList' class='avi-tip avi-menu-shortcut' title='Open Battle'/>"),
                fishing: $("<a href='javascript:;' data-delegate-click='#loadFishing' class='avi-tip avi-menu-shortcut' title='Open Fishing'/>"),
                wc: $("<a href='javascript:;' data-delegate-click='#loadWoodcutting' class='avi-tip avi-menu-shortcut' title='Open Lumber Mill'/>"),
                mine: $("<a href='javascript:;' data-delegate-click='#loadMining' class='avi-tip avi-menu-shortcut' title='Open Mine'/>"),
                quarry: $("<a href='javascript:;' data-delegate-click='#loadStonecutting' class='avi-tip avi-menu-shortcut' title='Open Quarry'/>")
            };
            $("#navigationWrapper").css("padding-top", $menuLink.height()).find("ul")
                .append(
                    $('<li class="avi-menu"/>')
                        .append($appends.battle)
                        .append($appends.fishing)
                        .append($appends.wc)
                        .append($appends.mine)
                        .append($appends.quarry)
                );
            modules.utils.svg($appends.battle, modules.urls.svg.sword_clash);
            modules.utils.svg($appends.fishing, modules.urls.svg.fishing);
            modules.utils.svg($appends.wc, modules.urls.svg.log);
            modules.utils.svg($appends.mine, modules.urls.svg.metal_bar);
            modules.utils.svg($appends.quarry, modules.urls.svg.stone_block);
            RoAModule.prototype.load.apply(this);
        }
    });
    UIActionShortcuts.prototype.constructor = UIActionShortcuts;
    modules.uiActionShortcuts = new UIActionShortcuts();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    var wnd;
    var requestHistory = {};
    function onClick() {
        wnd.toggle();
    }
    function updateDebugContent() {
        var $tableBody = $('#debugWindowContentBody');
        $tableBody.empty();
        for(var key in requestHistory) {
            var $rowRcvLink = $('<a href="javascript:;">Log to Console</a>').click({key: key}, function (event) {
                console.log('DEBUG: Printing data for ' + event.data.key);
                console.log(requestHistory[event.data.key].data);
            });
            var $rowSentLink = $('<a href="javascript:;">Log to Console</a>').click({key: key}, function (event) {
                console.log('DEBUG: Printing Sent data for ' + event.data.key);
                console.log(requestHistory[event.data.key].dataSent);
            });
            var timeString = requestHistory[key].time.getHours() + ":" + requestHistory[key].time.getMinutes() + ":" + requestHistory[key].time.getSeconds();;
            var $row = $('<tr></tr>');
            $row.append($('<td>' + key + '</td>'));
            $row.append($('<td>' + timeString + '</td>'));
            $row.append($('<td></td>').append($rowSentLink));
            $row.append($('<td></td>').append($rowRcvLink));
            $tableBody.append($row);
        }
    }
    function initEntry(url) {
        if(requestHistory[url]) {
            requestHistory[url].time = new Date();
            return;
        }
        requestHistory[url] = { time: new Date(), data: null, dataSent: null };
    }
    function onAjaxDone(requestData) {
        initEntry(requestData.url);
        requestHistory[requestData.url].data = requestData;
        updateDebugContent();
    }
    function onAjaxSentPending(requestData) {
        initEntry(requestData.url);
        requestHistory[requestData.url].dataSent = requestData;
        updateDebugContent();
    }
    function UIDebugWindow() {
        RoAModule.call(this, "UI Debug Window");
    }
    UIDebugWindow.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#debugWindowTitle"});
            wnd.resizable();
            wnd.hide();
            $('#debugWindowClose').click(function () {
                wnd.hide();
            });
            modules.ajaxHooks.registerAll(onAjaxDone);
            modules.ajaxHooks.registerRcvAll(onAjaxSentPending);
            modules.uiScriptMenu.addLink("Debug", onClick);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.debugWindow;
            this.continueLoad();
        }
    });
    UIDebugWindow.prototype.constructor = UIDebugWindow;
    modules.uiDebugWindow = new UIDebugWindow();
})(modules.jQuery);

(function ($) {
    'use strict';
    var timers = {};
    function updateEffectStatus(requestData) {
        if(!requestData.json.p || !requestData.json.p.mods) {
            return;
        }
        var existing = {};
        for (var mod in requestData.json.p.mods) {
            var name = requestData.json.p.mods[mod].n;
            var time = requestData.json.p.mods[mod].ends;
            if(!name || !time || isNaN(time)) {
                continue;
            }
            existing[name] = true;
            if (!timers[name]) {
                timers[name] = modules.createUITimer(name);
                timers[name].sound = modules.settings.settings.notification.effectExpire.sound;
                timers[name].notify = modules.settings.settings.notification.effectExpire.show;
            }
            timers[name].set(time);
            timers[name].resume();
        }
        for (var name in timers) {
            if (existing[name]) {
                continue;
            }
            timers[name].delete();
            delete timers[name];
        }
    }
    function EffectMonitor() {
        RoAModule.call(this, "Effect Monitor");
    }
    EffectMonitor.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            modules.ajaxRegisterAutoActions(updateEffectStatus);
            RoAModule.prototype.load.apply(this);
        }
    });
    EffectMonitor.prototype.constructor = EffectMonitor;
    modules.effectMonitor = new EffectMonitor();
})(modules.jQuery);

(function () {
    'use strict';
    var eventTimer;
    var timeSinceEventTimer;
    function updateEventStatus(requestData) {
        if(!requestData.json.p) {
            return;
        }
        if(requestData.json.p.event_time && requestData.json.p.event_time > 0) {
            modules.settings.settings.lastEventTime = null;
            if(timeSinceEventTimer) {
                timeSinceEventTimer.delete();
                timeSinceEventTimer = null;
            }
            if(!eventTimer) {
                eventTimer = modules.createUITimer("Next Event");
                eventTimer.sound = modules.settings.settings.notification.event.sound;
                eventTimer.notify = modules.settings.settings.notification.event.show;
            }
            eventTimer.set(requestData.json.p.event_time);
            eventTimer.resume();
        } else if (eventTimer) {
            eventTimer.delete();
            eventTimer = null;
            if(!timeSinceEventTimer) {
                modules.settings.settings.lastEventTime = new Date();
                createLastEventTimer(0);
            }
        }
    }
    function createLastEventTimer(time) {
        timeSinceEventTimer = modules.createUITimer("Last Event");
        timeSinceEventTimer.increment = true;
        timeSinceEventTimer.set(time);
        timeSinceEventTimer.resume();
    }
    function EventMonitor() {
        RoAModule.call(this, "Event Monitor");
    }
    EventMonitor.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            modules.ajaxRegisterAutoActions(updateEventStatus);
            if (modules.settings.settings.lastEventTime) {
                var timeSinceEvent = new Date() - Date.parse(modules.settings.settings.lastEventTime);
                createLastEventTimer(timeSinceEvent);
            }
            RoAModule.prototype.load.apply(this);
        }
    });
    EventMonitor.prototype.constructor = EventMonitor;
    modules.eventMonitor = new EventMonitor();
})();

(function ($) {
    'use strict';
    var template;
    var wnd;
    function onClick() {
        wnd.toggle();
    }
    function autoSave() {
        var text = $('.jqte_editor').html();
        modules.settings.settings.notes = text;
    }
    function UINoteWindow() {
        RoAModule.call(this, "UI Note Window");
    }
    UINoteWindow.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#noteTitle"});
            wnd.resizable();
            wnd.hide();
            $('#noteWindowClose').click(function () {
                wnd.hide();
            });
            $('#noteEditor').jqte();
            $('#noteEditor').jqteVal(modules.settings.settings.notes);
            modules.createInterval("noteAutoSave").set(autoSave, 5000);
            modules.uiScriptMenu.addLink("Notes", onClick);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.noteWindow;
            this.continueLoad();
        }
    });
    UINoteWindow.prototype.constructor = UINoteWindow;
    modules.uiNoteWindow = new UINoteWindow();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    var $menuContent;
    function UIScriptMenu() {
        RoAModule.call(this, "UI Script Menu");
    }
    UIScriptMenu.prototype = Object.spawn(RoAModule.prototype, {
        addLink: function (text, callback) {
            var link = $('<a href="javascript:;"/>');
            link.append($('<li class="visible-xs-inline-block visible-sm-inline-block visible-md-block visible-lg-block">' + text + '</li>'));
            link.click(callback);
            $menuContent.append(link);
            /*
             .html('<li class="visible-xs-inline-block visible-sm-inline-block visible-md-block visible-lg-block">Debug</li>')
             .click(onClick);*/
            /*<a href="javascript:;"><li class="visible-xs-inline-block visible-sm-inline-block visible-md-block visible-lg-block">Custom Timer</li></a>*/
        },
        continueLoad: function () {
            $('#navWrapper').prepend($(template));
            $('#roaMenuTitle').text(GM_info.script.name + " " + GM_info.script.version);
            $menuContent = $("#roaMenuContent");
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.scriptMenu;
            this.continueLoad();
        }
    });
    UIScriptMenu.prototype.constructor = UIScriptMenu;
    modules.uiScriptMenu = new UIScriptMenu();
})(modules.jQuery);

(function () {
    'use strict';
    var timer;
    function SessionTime() {
        RoAModule.call(this, "Session Time");
    }
    SessionTime.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            timer = modules.createUITimer("Session Time");
            timer.increment = true;
            timer.set(0);
            timer.resume();
            RoAModule.prototype.load.apply(this);
        }
    });
    SessionTime.prototype.constructor = SessionTime;
    modules.sessionTime = new SessionTime();
})();

(function ($) {
    'use strict';
    function PlayerGainTracker() {
        RoAModule.call(this, "Player Gain-Tracker");
    }
    PlayerGainTracker.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            RoAModule.prototype.load.apply(this);
        }
    });
    PlayerGainTracker.prototype.constructor = PlayerGainTracker;
    modules.playerGainTracker = new PlayerGainTracker();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    var wnd;
    function onClick() {
        wnd.toggle();
    }
    function PlayerGainWindow() {
        RoAModule.call(this, "Player Gain Window");
    }
    PlayerGainWindow.prototype = Object.spawn(RoAModule.prototype, {
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#gainWindowTitle"});
            wnd.resizable();
            wnd.hide();
            $('#gainWindowClose').click(function () {
                wnd.hide();
            });
            modules.uiScriptMenu.addLink("Player Gains", onClick);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.playerGainWindow;
            this.continueLoad();
        }
    });
    PlayerGainWindow.prototype.constructor = PlayerGainWindow;
    modules.playerGainWindow = new PlayerGainWindow();
})(modules.jQuery);

(function () {
    'use strict';
    const SettingType = {
        Toggle: 0,
    };
    const Setting = function (category, name, description, type) {
        this.category = category;
        this.name = name;
        this.description = description;
        this.type = type || SettingType.Toggle;
        this.load();
        if(modules.settingsWindow.loaded) {
            modules.settingsWindow.register(this);
        }
    };
    Setting.prototype = {
        category: null,
        name: null,
        description: null,
        type: null,
        callback: null,
        value: null,
        load: function() {
            if(!modules.settings.dynamicSettings) {
                modules.settings.dynamicSettings = {};
            }
            switch (this.type) {
                case SettingType.Toggle: {
                    this.value = modules.settings.dynamicSettings[this.name] || false;
                    break;
                }
                default: {
                    modules.logger.error("Unknown Setting Type: " + this.type + " for " + this.name);
                }
            }
        },
        save: function () {
            if(!modules.settings.dynamicSettings) {
                modules.settings.dynamicSettings = {};
            }
            switch (this.type) {
                case SettingType.Toggle: {
                    modules.settings.dynamicSettings[this.name] = this.value;
                    break;
                }
                default: {
                    modules.logger.error("Unknown Setting Type: " + this.type + " for " + this.name);
                }
            }
        }
    };
    modules.settingTypes = SettingType;
    modules.createSetting = function (category, name, description, type) {
        return new Setting(category, name, description, type);
    };
})();

(function($) {
    'use strict';
    var autoSaveInterval;
    function Settings() {
        this.settings = this.defaults;
        autoSaveInterval = modules.createInterval("settingsAutoSave");
        RoAModule.call(this, "Settings");
    }
    Settings.prototype = Object.spawn(RoAModule.prototype, {
        defaults: {
            version: modules.constants.SettingsSaveVersion,
            notification: {
                enable: false,
                enableSound: false,
                whisper: {
                    sound: true,
                    show: true
                },
                house: {
                    sound: true,
                    show: true
                },
                event: {
                    sound: true,
                    show: true
                },
                captcha: {
                    sound: false,
                    show: true
                },
                effectExpire: {
                    sound: false,
                    show: true
                }
            },
            features: {
                house_timer: true
            },
            dynamicSettings: {},
            dungeonMap: {},
            dungeonData: {},
            chartData: {},
            timerData: {},
            lastEventTime: null,
            notes: ""
        },
        save: function () {
            GM_setValue(modules.constants.SettingsSaveKey, JSON.stringify(this.settings));
        },
        load: function () {
            var data = JSON.parse(GM_getValue(modules.constants.SettingsSaveKey) || "{}");
            if(data.version === modules.constants.SettingsSaveVersion) {
                this.settings = $.extend(true, this.defaults, data);
            }
            autoSaveInterval.set(function () {
                modules.settings.save();
            }, modules.constants.SettingsAutoSaveInterval);
            RoAModule.prototype.load.apply(this);
        }
    });
    Settings.prototype.constructor = Settings;
    modules.settings = new Settings();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    var wnd;
    function buildHeader(title) {
        return $('<div class="row"><div class="col-xs-12"><h4 class="nobg center">' + title + '</h4></div></div>');
    }
    function notifySettingChange(category, name) {
        if(modules.settingsWindow.settings[category][name].callback) {
            modules.settingsWindow.settings[category][name].callback();
        }
    }
    function buildToggleEntry(setting) {
        var optionOff = $('<option value="0">Disabled</option>');
        var optionOn = $('<option value="1">Enabled</option>');
        var select = $('<select></select>');
        select.append(optionOff);
        select.append(optionOn);
        select.change({cat: setting.category, name: setting.name}, function (e) {
            modules.settingsWindow.settings[e.data.cat][e.data.name].value = parseInt(this.value) === 1;
            notifySettingChange(e.data.cat, e.data.name);
        });
        var selectWrapper = $('<div class="col-xs-4 col-md-2"></div>');
        selectWrapper.append(select);
        var text = $('<div class="col-xs-8 col-md-10">' + setting.name + '</div>');
        var content = $('<div class="col-xs-12"></div>');
        content.append(selectWrapper);
        content.append(text);
        var wrapper = $('<div class="row mt10"></div>');
        wrapper.append(content);
        return wrapper;
    }
    function rebuildSettingWindow() {
        modules.logger.log("Rebuilding Settings Window");
        var parent = $('#settingsWindowContent');
        parent.empty();
        var categories = Object.keys(modules.settingsWindow.settings).sort();
        for (var i = 0; i < categories.length; i++) {
            var category = categories[i];
            var settingsList = modules.settingsWindow.settings[category];
            var header = buildHeader(category);
            parent.append(header);
            for(var name in settingsList) {
                var setting = settingsList[name];
                switch (setting.type) {
                    case modules.settingTypes.Toggle: {
                        var entry = buildToggleEntry(setting);
                        parent.append(entry);
                        break;
                    }
                    default: {
                        modules.logger.warn("Setting type not implemented in Settings Window: " + setting.type);
                    }
                }
            }
        }
    }
    function onClick() {
        wnd.toggle();
    }
    function SettingsWindow() {
        RoAModule.call(this, "Settings Window");
    }
    SettingsWindow.prototype = Object.spawn(RoAModule.prototype, {
        settings: {},
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#settingsWindowTitle"});
            wnd.resizable();
            wnd.hide();
            $('#settingsWindowClose').click(function () {
                wnd.hide();
            });
            modules.uiScriptMenu.addLink("Settings", onClick);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.settingsWindow;
            this.continueLoad();
        },
        register: function (setting) {
            if(!this.settings[setting.category]) {
                this.settings[setting.category] = {};
            }
            this.settings[setting.category][setting.name] = setting;
            rebuildSettingWindow();
        }
    });
    SettingsWindow.prototype.constructor = SettingsWindow;
    modules.settingsWindow = new SettingsWindow();
})(modules.jQuery);

(function () {
    'use strict';
    const UpdateInterval = modules.createInterval("UITimerUpdate");
    UpdateInterval.set(updateTimers, 10);
    var timers = {};
    function updateTimers() {
        for (var name in timers) {
            timers[name].update();
        }
    }
    function UITimer(name, canEdit) {
        this.name = name;
        this.canEdit = canEdit;
        timers[name] = this;
        modules.uiTimerMenu.registerTimer(this);
    }
    UITimer.prototype = {
        name: null,
        sound: false,
        notify: false,
        lastUpdate: null,
        startValue: 0,
        remaining: 0,
        ended: true,
        callback: null,
        paused: false,
        canEdit: false,
        increment: false,
        set: function (timeInSeconds, callback) {
            this.remaining = timeInSeconds * 1000;
            this.startValue = this.remaining;
            this.ended = false;
            this.callback = callback;
        },
        setFromData: function (data) {
            this.remaining = data.r;
            this.startValue = data.st;
            this.notify = data.n;
            this.sound = data.s;
            var tdiff = new Date() - Date.parse(data.t);
            if(!tdiff || isNaN(tdiff)) { tdiff = 0; }
            this.remaining = data.r - tdiff;
        },
        end: function () {
            this.remaining = 0;
        },
        getStartTimeString : function () {
            return new Date(this.startValue).toISOString().substr(11, 8);
        },
        getTimeString: function () {
            return new Date(this.remaining).toISOString().substr(11, 8);
        },
        resume: function () {
            this.lastUpdate = new Date();
            this.paused = false;
            this.ended = false;
        },
        suspend: function () {
            this.paused = true;
        },
        delete: function () {
            modules.uiTimerMenu.unregisterTimer(this.name);
            delete timers[this.name];
        },
        save: function () {
            return {
                t: new Date(),
                r: this.remaining,
                st: this.startValue,
                s: this.sound,
                n: this.notify
            };
        },
        update: function () {
            if (this.paused) {
                return;
            }
            var newUpdateTime = new Date();
            var diff = newUpdateTime - this.lastUpdate;
            this.lastUpdate = newUpdateTime;
            if (this.increment) {
                this.remaining = this.remaining + diff;
            } else {
                this.remaining = this.remaining - diff;
            }
            if (this.remaining <= 0) {
                this.remaining = 0;
                this.ended = true;
                this.suspend();
                if (this.sound) {
                    console.warn("TODO: implement SFX");
                }
                if (this.notify) {
                    modules.notification.notice("Timer has Ended: " + this.name);
                }
                if (this.callback) {
                    this.callback();
                }
            }
        }
    };
    modules.createUITimer = function (name, canEdit) {
        return new UITimer(name, canEdit);
    };
})();

(function ($) {
    'use strict';
    var wnd;
    var template;
    function showFeedback(msg) {
        $('#createTimerFeedback').text(msg);
    }
    function clearCreateInput() {
        $('#customTimerOptName').val("");
        $('#customTimerOptHour').val("");
        $('#customTimerOptMinute').val("");
        $('#customTimerOptSecond').val("");
    }
    function createTimer() {
        var name = $('#customTimerOptName').val();
        var hour = parseInt($('#customTimerOptHour').val());
        var minute = parseInt($('#customTimerOptMinute').val());
        var second = parseInt($('#customTimerOptSecond').val());
        var sound = $('#customTimerOptSound').is(':checked');
        var notify = $('#customTimerOptNotify').is(':checked');
        if(!hour || isNaN(hour)) { hour = 0; }
        if(!minute || isNaN(minute)) { minute = 0; }
        if(!second || isNaN(second)) { second = 0; }
        clearCreateInput();
        if(!name || name.length <= 0) {
            showFeedback("Invalid name");
            return;
        }
        if(hour <= 0 && minute <= 0 && second <= 0) {
            showFeedback("Invalid Time set!");
            return;
        }
        var timeInSeconds = (hour * 60 * 60) + (minute * 60) + second;
        var timer = modules.createUITimer(name, true);
        timer.sound = sound;
        timer.notify = notify;
        timer.set(timeInSeconds);
        timer.resume();
    }
    function UITimerEditor() {
        RoAModule.call(this, "UI Timer Editor");
    }
    UITimerEditor.prototype = Object.spawn(RoAModule.prototype, {
        show: function () {
            wnd.show();
        },
        continueLoad: function () {
            wnd = $(template);
            wnd.appendTo("body");
            wnd.draggable({handle:"#timerEditorTitle"});
            wnd.resizable();
            wnd.hide();
            $('#timerEditorWindowClose').click(function () {
                wnd.hide();
            });
            $('#customTimerCreateButton').click(function () {
                createTimer();
            });
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.timerEditor;
            this.continueLoad();
        }
    });
    UITimerEditor.prototype.constructor = UITimerEditor;
    modules.uiTimerEditor = new UITimerEditor();
})(modules.jQuery);

(function ($) {
    'use strict';
    var template;
    function UITimerMenu() {
        RoAModule.call(this, "UI Timer Menu");
    }
    var deleteTimer = function (event) {
        modules.uiTimerMenu.deleteTimer(event.data.name);
    };
    var createListEntry = function (title, canEdit) {
        var $label = $('<div class="col-xs-6 col-md-12 col-lg-5 gold timerLabel">' + title + '</div>');
        var $wrapper = $('<div class="col-xs-6 col-md-12 col-lg-7"/>');
        var $span = $('<span id="avi-house-construction" class="timerValue"/>');
        $wrapper.append($span);
        if (canEdit) {
            var $delete = $('<a href="javascript:;" class="timerDelete"><span>[X]</span></a>');
            $delete.click({name: title}, deleteTimer);
            $wrapper.append($delete);
        }
        var $entry = $('<div/>');
        $entry.append($label).append($wrapper);
        return { entry: $entry, span: $span };
    };
    var refreshTimers = function () {
        modules.uiTimerMenu.refreshTimerList();
    };
    var saveTimers = function () {
        modules.uiTimerMenu.save();
    };
    UITimerMenu.prototype = Object.spawn(RoAModule.prototype, {
        activeTimers: {},
        activeTimerEntries: {},
        suspendRefresh: false,
        rebuildTimerList: function () {
            this.suspendRefresh = true;
            var $content = $('#timerMenuContents');
            $content.empty();
            this.activeTimerEntries = {};
            var names = Object.keys(this.activeTimers);
            names.sort();
            for(var i = 0; i < names.length; i++) {
                var entry = createListEntry(names[i], this.activeTimers[names[i]].canEdit);
                $content.append(entry.entry);
                this.activeTimerEntries[names[i]] = entry;
            }
            this.suspendRefresh = false;
            this.refreshTimerList();
        },
        refreshTimerList: function () {
            if (this.suspendRefresh) {
                return;
            }
            for(var name in this.activeTimers) {
                if(this.activeTimers[name].ended === true) {
                    this.activeTimerEntries[name].span.text("Ended (" + this.activeTimers[name].getStartTimeString() + ")");
                } else {
                    this.activeTimerEntries[name].span.text(this.activeTimers[name].getTimeString());
                }
            }
        },
        registerTimer: function (timer) {
            this.activeTimers[timer.name] = timer;
            this.rebuildTimerList();
        },
        unregisterTimer: function (name) {
            delete this.activeTimers[name];
            this.rebuildTimerList();
        },
        deleteTimer: function (name) {
            this.activeTimers[name].delete();
        },
        continueLoad: function() {
            $('#rightWrapper').append($(template));
            $('#timerEditorOpen').click(function () {
                modules.uiTimerEditor.show();
            });
            var savedData = modules.settings.settings.timerData;
            if(savedData) {
                for (var name in savedData) {
                    var timer = modules.createUITimer(name, true);
                    timer.setFromData(savedData[name]);
                    timer.resume();
                }
            }
            modules.createInterval("timerMenuRefresh").set(refreshTimers, 10);
            modules.createInterval("timerSaveInterval").set(saveTimers, 100);
            RoAModule.prototype.load.apply(this);
        },
        load: function () {
            template = modules.templates.timerMenu;
            this.continueLoad();
        },
        save: function () {
            var data = {};
            for (var name in this.activeTimers) {
                if (!this.activeTimers[name].canEdit || this.activeTimers[name].callback) {
                    continue;
                }
                data[name] = this.activeTimers[name].save();
            }
            modules.settings.settings.timerData = data;
        }
    });
    UITimerMenu.prototype.constructor = UITimerMenu;
    modules.uiTimerMenu = new UITimerMenu();
})(modules.jQuery);

(function () {
    function initializeEssentials() {
        modules.loader.register(modules.cache, true);
        modules.loader.register(modules.css, true);
        modules.loader.register(modules.ajaxHooks, true);
        modules.loader.register(modules.uiScriptMenu, true);
        modules.loader.register(modules.uiTimerMenu, true);
        modules.loader.register(modules.automateControl, true);
        modules.loader.register(modules.settingsWindow, true);
    }
    function initializeOptionals() {
        modules.loader.register(modules.automateStamina);
        modules.loader.register(modules.chartWindow);
        modules.loader.register(modules.chatPeopleColor);
        modules.loader.register(modules.chatTabs);
        modules.loader.register(modules.clanDonations);
        modules.loader.register(modules.dungeonTracker);
        modules.loader.register(modules.dungeonMap);
        modules.loader.register(modules.dungeonAutomate);
        modules.loader.register(modules.dungeonWindow);
        modules.loader.register(modules.houseMonitor);
        modules.loader.register(modules.houseHarvestRepeater);
        modules.loader.register(modules.uiDebugWindow);
        modules.loader.register(modules.uiNoteWindow);
        modules.loader.register(modules.uiTimerEditor);
        modules.loader.register(modules.uiActionShortcuts);
        modules.loader.register(modules.effectMonitor);
        modules.loader.register(modules.eventMonitor);
        modules.loader.register(modules.sessionTime);
        modules.loader.register(modules.playerGainTracker);
        modules.loader.register(modules.playerGainWindow);
    }
    modules.loader.loadCallback = function () {
        initializeEssentials();
        initializeOptionals();
    }
})();

(function ($) {
    var interval;
    var inProgress = false;
    var currentDelayAction;
    function executeJQueryClick(action) {
        var control = $(action.control);
        if(action.findClause) {
            control = control.find(action.findClause).first();
        }
        if(control.length === 0 || control.is(":disabled") || control.hasClass("disabled") || control.hasClass("paused")) {
            modules.automateControl.pendingActions.push(action);
            inProgress = false;
            return;
        }
        control.click();
        inProgress = false;
    }
    function beginExecuteDelayAction(action) {
        if(!action.time || action.time <= 0) {
            modules.logger.error("Invalid Time on Delay Control Action!");
            inProgress = false;
            return;
        }
        currentDelayAction = action;
        currentDelayAction.startTime = Date.now();
        currentDelayAction.elapsed = 0;
    }
    function continueExecuteDelayAction() {
        currentDelayAction.elapsed += Date.now() - currentDelayAction.startTime;
        if(currentDelayAction.elapsed >= currentDelayAction.time) {
            inProgress = false;
            currentDelayAction = null;
        }
    }
    function execute(action) {
        switch (action.type) {
            case modules.automateActionTypes.JQueryClick: {
                executeJQueryClick(action);
                break;
            }
            case modules.automateActionTypes.Delay: {
                beginExecuteDelayAction(action);
                break;
            }
            default: {
                modules.logger.warn("Unknown Automate Action Type: " + action.type);
                inProgress = false;
            }
        }
    }
    function onUpdateAutomateControl() {
        modules.automateControl.update();
    }
    function AutomateControl() {
        RoAModule.call(this, "Automate Control");
    }
    AutomateControl.prototype = Object.spawn(RoAModule.prototype, {
        pendingActions: [],
        load: function () {
            interval = modules.createInterval("AutomateControl");
            interval.set(onUpdateAutomateControl, 200);
            RoAModule.prototype.load.apply(this);
        },
        isIdle: function () {
            return this.pendingActions.length <= 0 && !inProgress;
        },
        add: function (action) {
            this.pendingActions.unshift(action);
        },
        clear: function () {
            this.pendingActions = [];
        },
        update: function () {
            if(currentDelayAction) {
                continueExecuteDelayAction();
                return;
            }
            if(!$( document ).ready() || !modules.ajaxHooks.idle) {
                return;
            }
            if(this.pendingActions.length > 0) {
                inProgress = true;
                execute(this.pendingActions.pop());
            }
        }
    });
    AutomateControl.prototype.constructor = AutomateControl;
    modules.automateControl = new AutomateControl();
})(modules.jQuery);

(function () {
    var actionType = {
        JQueryClick: 0,
        Delay: 1
    };
    function AutomateControlAction(type) {
        RoAModule.call(this, "Automate Control Action");
        this.type = type;
    }
    AutomateControlAction.prototype = Object.spawn(RoAModule.prototype, {
        type: null,
        pendingActions: [],
        load: function () {
            RoAModule.prototype.load.apply(this);
        }
    });
    AutomateControlAction.prototype.constructor = AutomateControlAction;
    modules.automateActionTypes = actionType;
    modules.createAutomateAction = function (type) {
        return new AutomateControlAction(type);
    };
})();

(function ($) {
    'use strict';
    var autoMax = 0;
    var autoCurr = 0;
    var enabled = true;
    var allowAuto = true;
    var replenishRequest;
    function toggleAuto(self) {
        enabled = !enabled;
        console.log("Toggled auto " + enabled);
        var $this = $(this)
        if (enabled) {
            $this.text('ON');
        } else {
            $this.text('OFF');
        }
    }
    function updateAutoState(json)
    {
        autoMax = parseInt(json.autosMax);
        autoCurr = parseInt(json.autosRemaining);
    }
    function updateAutoStamina(requestData) {
        if(requestData.json != null && requestData.json.p != null && requestData.json.p.autosMax != null)
        {
            updateAutoState(requestData.json.p);
            if(!allowAuto) {
                allowAuto = autoMax > 5 && autoCurr > 0 && autoCurr >= autoMax - 1;
            }
        }
        if(modules.session.lockAutomation) {
            return;
        }
        if(enabled && allowAuto && autoMax > 5 && autoCurr > 0 && autoCurr < autoMax && autoCurr < 3)
        {
            allowAuto = false;
            replenishRequest.send();
        }
    }
    function onStaminaReplenish(requestData) {
        if (requestData.json.captcha) {
            modules.session.captchaEncountered();
        }
    }
    function createToggle(target) {
        var toggleButton = $("<button class='btn btn-primary'/>");
        toggleButton.click(toggleAuto);
        toggleButton.text("ON");
        $('#' + target).prepend(toggleButton);
    }
    function AutoStamina() {
        RoAModule.call(this, "Auto Stamina");
    }
    AutoStamina.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            createToggle('craftingStatusButtons');
            createToggle('battleStatusButtons');
            createToggle('harvestStatusButtons');
            createToggle('harvestBossStatusButtons');
            createToggle('bossStatusButtons');
            replenishRequest = modules.createAjaxRequest('stamina_replenish.php').post();
            modules.ajaxHooks.register('stamina_replenish.php', onStaminaReplenish);
            modules.ajaxRegisterAutoActions(updateAutoStamina);
            RoAModule.prototype.load.apply(this);
        }
    });
    AutoStamina.prototype.constructor = AutoStamina;
    modules.automateStamina = new AutoStamina();
})(modules.jQuery);

(function ($) {
    var timer;
    var selectedSkill = null;
    var selectedTime = null;
    var request;
    var setting;
    var lastRepeat = Date.now();
    function updateHarvestState() {
        if(!setting.value || selectedSkill === null || selectedTime === null) {
            return;
        }
        if($('#harvestronNotifier').css('display') === 'none') {
            return;
        }
        if(Date.now() - lastRepeat < modules.constants.HarvestRepeaterMinDelay) {
            return;
        }
        lastRepeat = Date.now();
        modules.logger.log("Re-sending Harvest");
        request.post({skill: selectedSkill, minutes: selectedTime});
        request.send();
        $('#harvestronNotifier').css('display', 'none');
    }
    function onSettingChanged() {
        modules.logger.log("Harvest Repeater turned " + (setting.value ? "On" : "Off"));
    }
    function captureHarvestronJob(requestData) {
        var match = requestData.options.data.match(/skill=([0-9]+).*?minutes=([0-9]+)/);
        if(match.length !== 3) {
            return;
        }
        selectedSkill = parseInt(match[1]);
        selectedTime = parseInt(match[2]);
        console.log("Harvest Repeater Set to: " + selectedSkill + "@" + selectedTime);
    }
    function HouseHarvestRepeater() {
        RoAModule.call(this, "House Harvest Repeater");
    }
    HouseHarvestRepeater.prototype = Object.spawn(RoAModule.prototype, {
        load: function () {
            timer = modules.createInterval("HouseHarvestRepeater");
            timer.set(updateHarvestState, 500);
            modules.ajaxHooks.registerRcv("house_harvest_job.php", captureHarvestronJob);
            request = modules.createAjaxRequest("house_harvest_job.php");
            setting = modules.createSetting("House", "Repeat Harvest", "Repeats the last started Harvestron job until turned off");
            setting.callback = onSettingChanged;
            RoAModule.prototype.load.apply(this);
        }
    });
    HouseHarvestRepeater.prototype.constructor = HouseHarvestRepeater;
    modules.houseHarvestRepeater = new HouseHarvestRepeater();
})(modules.jQuery);

console.log("Loading " + GM_info.script.name);
modules.settings.load();
modules.logger.load();
modules.notification.load();
if (typeof(window.sessionStorage) === "undefined") {
    modules.notification.incompatibility("Session storage");
} else if (typeof(MutationObserver) === "undefined") {
    modules.notification.incompatibility("MutationObserver");
} else {
    modules.loader.load();
}

